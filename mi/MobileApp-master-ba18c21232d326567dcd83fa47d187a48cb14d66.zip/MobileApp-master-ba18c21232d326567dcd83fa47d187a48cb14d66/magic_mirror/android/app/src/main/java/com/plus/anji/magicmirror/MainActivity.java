package com.plus.anji.magicmirror;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import io.flutter.app.FlutterActivity;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;
import io.flutter.plugins.GeneratedPluginRegistrant;

public class MainActivity extends FlutterActivity {
  private static final String CHANNEL = "flutter_get_html";

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    //获取方法渠道来源
    new MethodChannel(getFlutterView(), CHANNEL)
            .setMethodCallHandler(new MethodChannel.MethodCallHandler() { //设置方法调用处理程序
              @Override
              public void onMethodCall(MethodCall methodCall, MethodChannel.Result result) {
                //获取channel方法名
                switch (methodCall.method) {
                  case "getLocalHtml":
                    result.success("file:///android_asset/html/NotFindPage.html");
                  default:
                    result.notImplemented();
                }
              }
            });

    GeneratedPluginRegistrant.registerWith(this);
  }

}
