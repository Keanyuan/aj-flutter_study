import UIKit
import Flutter

@UIApplicationMain
@objc class AppDelegate: FlutterAppDelegate {
  override func application(
    _ application: UIApplication,
    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
  ) -> Bool {
    
    GeneratedPluginRegistrant.register(with: self)
    
    let controller: FlutterViewController = self.window?.rootViewController as! FlutterViewController

    let batteryChannel = FlutterMethodChannel(name: "flutter_get_html", binaryMessenger: controller)

    batteryChannel.setMethodCallHandler { (call, result) in
        switch(call.method){
        case "getLocalHtml":
//            let bundlePath = Bundle.main.bundlePath
            let bundlePath = Bundle.main.path(forResource: "NotFindPage", ofType: "html", inDirectory: "html")
            result("\(bundlePath ?? "")");
//            result("file://\(bundlePath)/html/NotFindPage.html")
        default:
            result(FlutterMethodNotImplemented)
        }
    }
    
    return super.application(application, didFinishLaunchingWithOptions: launchOptions)
  }
}
