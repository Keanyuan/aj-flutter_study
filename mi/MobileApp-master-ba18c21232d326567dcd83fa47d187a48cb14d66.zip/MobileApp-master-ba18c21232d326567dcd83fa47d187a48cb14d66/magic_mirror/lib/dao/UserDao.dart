
import 'dart:convert';
import 'dart:io';
import 'package:aj_flutter_plugin/aj_flutter_plugin.dart';
import 'package:magic_mirror/model/AppVersionModel.dart';
import 'package:magic_mirror/model/GroupListModel.dart';
import 'package:magic_mirror/model/HomeListRepModel.dart';
import 'package:magic_mirror/model/ReportListModelRep.dart';
import 'package:magic_mirror/model/User.dart';
import 'package:magic_mirror/request/Address.dart';
import 'package:magic_mirror/request/HttpManager.dart';
import 'package:magic_mirror/tools/CommonUtils.dart';
import 'package:magic_mirror/tools/Config.dart';
import 'package:magic_mirror/tools/DataResult.dart';
import 'package:magic_mirror/tools/LocalStorage.dart';
import 'package:redux/redux.dart';
import 'package:magic_mirror/reducer/UserReducer.dart';
import 'package:version/version.dart';

class UserDao {

  //初始化用户信息
  static initUserInfo(Store store) async {
    var token = await LocalStorage.get(AJConfig.TOKEN_KEY);

    //获取本地用户信息
    var res = await getUserInfoLocal();

    //如果用户信息不为空保存到reduce中
    if (res != null && res.result && token != null){
      store.dispatch(UpdateUserAction(res.data));
    }

    ///读取主题颜色
    String themeIndex = await LocalStorage.get(AJConfig.THEME_COLOR);
    if (themeIndex != null && themeIndex.length != 0) {
      CommonUtils.pushTheme(store, int.parse(themeIndex));
    }
    return new DataResult(res.data, (res.result && (token != null)));
  }

  ///退出登录
  static clearAll(Store store) async {
    HttpManager.clearAuthorization();
    LocalStorage.remove(AJConfig.USER_INFO);
    store.dispatch(new UpdateUserAction(User.empty()));
  }


  ///获取本地登录用户信息
  static getUserInfoLocal()async{
    //JSON 字符串
    var userText = await LocalStorage.get(AJConfig.USER_INFO);
    if(userText != null){
      var userMap = json.decode(userText);
      User user = User.fromJson(userMap);
      return new DataResult(user, true);
    } else {
      return new DataResult(null, false);
    }
  }

  static getVerificationCode() async {
    var res = await HttpManager.requestData(Address.getVerificationCode, null, null, optionMetod: "get",isNeedToken: false, needSign: false);
    var resultData;
    if(res != null && res.result){
      Map<String, dynamic> r = res.data;
      Map<String, dynamic>  map = new Map();
      map["code"] = r["code"];
      map["codeId"] = r["codeId"];
      resultData = map;
      return new DataResult(resultData, res.result);
    }

    return new DataResult(resultData, false);

  }


  static getMirrorAccessUserSendMail(email, verificationCode, codeId, store) async {
    var params = {
      "email": email,
      "verificationCode": verificationCode,
      "codeId": codeId,
      "url": "resetpassword",
    };
    var res = await HttpManager.requestData(Address.accessUserSendMail, params, null, isNeedToken: false);
    if(res != null && res.result){
      return new DataResult(true, res.result);
    }
    return new DataResult(false, false);
  }

  static getMirrorCreateOrUpdateUser(userName, phone, email, password, confirmPassword, store) async {
    var params = {
      "userName": userName,
      "phone": phone,
      "email": email,
      "password": password,
      "confirmPassword": confirmPassword,
      "nikeName": userName
    };
    var res = await HttpManager.requestData(Address.createOrUpdateUser, params, null, isNeedToken: false);
    if(res != null && res.result){
      return new DataResult(true, res.result);
    }
    return new DataResult(false, false);
  }

    /// 登录 二期 accessUser/login
  static getMirrorLogin(userName, password, store) async {
    HttpManager.clearAuthorization();

//    String params = "?username=$userName&password=$password";
     var params = {
      "userName" : userName,
      "password" : password,
       "isFrom": "app",
     };
//    var res = await HttpManager.netFetch(Address.accessUserLoginUrl, params, null, null);
    var res = await HttpManager.requestData(Address.accessUserLoginUrl, params, null, isNeedToken: false);
    var resultData;
    if(res != null && res.result){
      Map<String, dynamic> r = res.data;
      Map<String, dynamic>  map = new Map();
      map["userId"] = r["accessUser"]["userId"];
      map["username"] = r["accessUser"]["userName"];
      map["email"] = r["accessUser"]["email"];
      map["userType"] = 1;
      map["token"] = r["token"];
      map["token"] = r["token"];
      map["proArr"] = [];
      var resultDataTemp = await getUserInfo(map);
      resultData = resultDataTemp;
      store.dispatch(new UpdateUserAction(resultData.data));
    }
    return new DataResult(resultData, res.result);
  }


  static getUserInfo(res) async{

    User user = User.fromJson(res);
    if(user.userId != null){
      LocalStorage.save(AJConfig.USER_INFO, json.encode(user.toJson(user)));
      return new DataResult(user, true);
    } else {
      return new DataResult(res, false);
    }
  }






  //报表列表  二期
  static queryChartListByPage(pageNumber , pageSize, projectId , {groupId = ""})async {

    Map<String, dynamic> requestParams = Map();

    requestParams = {
      "currentPage" : pageNumber,
      "pageSize" : pageSize,
      "projectId" : projectId,
      "isFrom": "app",
      "groupId": groupId
    };
    var res = await HttpManager.requestData(Address.queryChartListByPage, requestParams, null);
    var resultData;
    if(res != null && res.result){
      ReportListModelRep reportListModelRep = ReportListModelRep.fromJson(res.data);
      resultData = reportListModelRep;
      return new DataResult(resultData, true);
    }
    return new DataResult(resultData, res.result);
  }

  //获取图表详情数据 二期
  static queryMirrorChartByChartId(chartId)async {

    //chart/mirrorChart/getMirrorChartByChartId/
    Map<String, dynamic> requestParams = Map();

    requestParams = {
      "chartId" : chartId,
      "showChartSize" : ""
    };
    var res = await HttpManager.requestData(Address.getMirrorChartByChartId, requestParams, null, needError: false);
    var resultData;
    if(res != null && res.result){
      if(res.data["unitArray"] is List){
        List list = res.data["unitArray"];
        if(list.length > 0){
          resultData = res.data["unitArray"][0];
        }
      }
      return new DataResult(resultData, true);
    }
    return new DataResult(resultData, res.result);
  }




  //请求GroupId 列表 二期
  static queryGroupList(projectId)async{
    Map<String, dynamic> requestParams = Map();
//    GroupListModel
    requestParams = {
      "target" : "chartManage",
      "projectId" : projectId,
      "isFrom": "app",
      "pageSize": 30
    };
    var res = await HttpManager.requestData(Address.queryGroupList, requestParams, null, needError: false);
    var resultData;
    if(res != null && res.result){
      if(res.data is List){
        List list = res.data;
        List<GroupListModel> groupList = [];
        list.map((item){
          groupList.add(GroupListModel.fromJson(item));
        }).toList();
        if(groupList.length > 0){
          resultData = groupList;
        }
      }

      return new DataResult(resultData, true);
    }
    return new DataResult(resultData, res.result);
  }


  //二期 首页 /project/selectByPage
  static getSelectByPage(pageNumber, pageSize, projectName)async{
//    String params = "?pageNumber=$pageNumber&pageSize=$pageSize";
    Map<String, dynamic> params = Map();
    if(projectName != null){
      params = {
        "keyword" : projectName,
        "isFrom": "app",
      };
    } else {
      params = {
        "currentPage" : pageNumber,
        "pageSize" : pageSize,
        "isFrom": "app",
      };
    }
    var res = await HttpManager.requestData(Address.selectByPage, params, null);
    var resultData;

    if(res != null && res.result){
      HomeListRepModel homeModelRep = HomeListRepModel.fromJson(res.data);
      resultData = homeModelRep;
      return new DataResult(homeModelRep, true);
    }
    return new DataResult(resultData, res.result);
  }

  //版本检测
  static checkVersion(app_version)async{
    AppVersionModel appVersionModel = AppVersionModel();
    if(app_version != null){
      final Version currentVersion = Version.parse(app_version);
      Version latestVersion = Version.parse(app_version);
      Map<String, dynamic> params = Map();
      var platformName = "android_app_version";
      if(Platform.isAndroid){
        platformName = "android_app_version";
      } else {
        platformName = "ios_app_version";

      }
      params = {
        "reqData" : {
          "paramName" : platformName
        }
      };

      var res = await HttpManager.requestData(Address.baseParameter_selectOne, params, null, isNeedToken: false, needSign: false, needError: false);

      if(res != null && res.result){
        if(AJConfig.DEBUG){print("paramValue ${res.data["paramValue"]}");}
        latestVersion = Version.parse("${res.data["paramValue"]}");
        appVersionModel.paramDesc = res.data["paramDesc"];
        appVersionModel.remark = res.data["remark"];
      }
      if(AJConfig.DEBUG){
        print(currentVersion);
        print(latestVersion);
      }
      if(latestVersion > currentVersion){
        appVersionModel.isInfoShow = true;
      }
    }
    return appVersionModel;
  }






}


