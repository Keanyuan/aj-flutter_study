
import 'package:flutter/material.dart';
import 'package:magic_mirror/style/AJColors.dart';

class AJCommonOptionWidget extends StatelessWidget {
  final List<AJOptionModel> moreList;


  AJCommonOptionWidget({this.moreList});


  //构建更多列表
  _renderHeaderPopItemChild(List<AJOptionModel> data){
    List<PopupMenuEntry<AJOptionModel>> list = new List();
    for(AJOptionModel item in data){
      list.add(PopupMenuItem<AJOptionModel>(
        child: new Text(item.name),
        value: item,));
    }
    return list;
  }



  //构建头部更多按钮
  _renderHeaderPopItem(List<AJOptionModel> list){
    return new PopupMenuButton<AJOptionModel>(
        child: new Icon(AJICons.MORE),
        onSelected: (model){
          model.selected(model);
        },
        itemBuilder: (BuildContext context){
          return _renderHeaderPopItemChild(list);
        }
    );
  }



  @override
  Widget build(BuildContext context) {

    List<AJOptionModel> list = [];
    if (moreList != null && moreList.length > 0){
      list.addAll(moreList);
    }
    return _renderHeaderPopItem(list);
  }

}

class AJOptionModel {
  final String name;
  final String value;
  final PopupMenuItemSelected<AJOptionModel> selected;

  AJOptionModel(this.name, this.value, this.selected);
}