import 'package:flutter/material.dart';
import 'package:magic_mirror/style/AJColors.dart';

class AJInputWidget extends StatefulWidget {
  static const defaultMargin = const EdgeInsets.only(left: 20.0, right: 20.0);

  //密码隐藏不可见
  final bool obscureText;

  //是否可以选择
  final bool enableInteractiveSelection;

  final TextInputAction textInputAction;


  //占位符
  final String hintText;

  final Color primarycolor;
  //钱准icon
  final IconData iconData;

  //带边框的前缀icon
  final IconData prefixIcon;
  final Widget suffix;

  final String errorText;
  final String helperText;


  //内容变化
  final ValueChanged<String> onChanged;

  //提交事件
  final ValueChanged<String> onSubmitted;

  //关注节点
  final FocusNode focusNode;


  //样式
  final TextStyle textStyle;

  //控制器
  final TextEditingController controller;

  //字体
  final FontWeight fontWeight;

  //字体大小
  final double fontSize;


  //字体颜色
  final Color labelColor;

  //占位符字体颜色
  final Color hintTextColor;


  final EdgeInsetsGeometry margin;



  AJInputWidget({Key key,this.obscureText = false,
    this.hintText,
    this.iconData,
    this.onChanged,
    this.textStyle,
    this.controller,
    this.prefixIcon,
    this.fontWeight,
    this.fontSize,
    this.hintTextColor,
    this.labelColor,
    this.margin = defaultMargin,
    this.enableInteractiveSelection=true,
    this.textInputAction = TextInputAction.done,
    this.onSubmitted,
    this.focusNode,
    this.errorText,
    this.helperText,
    this.suffix,
    this.primarycolor = AJColors.BLUE_COLOE
  }) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return _AJInputWidgetState();
  }

}

class _AJInputWidgetState extends State<AJInputWidget> {
  _AJInputWidgetState() : super();


  @override
  Widget build(BuildContext context) {
    return new Padding(
      padding: widget.margin,
      child: new AccentColorOverride(
        color: widget.primarycolor,
        child: new TextField(
          controller: widget.controller,
          focusNode: widget.focusNode,
          onChanged: widget.onChanged,
          onSubmitted: widget.onSubmitted,
          obscureText: widget.obscureText,
          enableInteractiveSelection: widget.enableInteractiveSelection,
          autocorrect: false,
          textInputAction: widget.textInputAction,
          decoration: new InputDecoration(
              hintText: widget.hintText,
              errorText: widget.errorText,
              helperText: widget.helperText,
              icon: widget.iconData == null ? null : new Icon(widget.iconData),
              prefixIcon: widget.prefixIcon == null ?  null : new Icon(widget.prefixIcon),
              suffix: widget.suffix,
              border:  widget.prefixIcon == null ?  UnderlineInputBorder() : OutlineInputBorder(),
              labelStyle: TextStyle(
                  fontWeight: widget.fontWeight == null ? null : widget.fontWeight,
                  fontSize: widget.fontSize == null ? null : widget.fontSize,
                  color: widget.labelColor == null ? null : widget.labelColor
              ),
              hintStyle: TextStyle(fontSize: widget.fontSize == null ? null : widget.fontSize, color: widget.hintTextColor == null ? null : widget.hintTextColor)
          ),
        ),
      ),);
  }

}


class AccentColorOverride extends StatelessWidget {

  const AccentColorOverride({Key key, this.color, this.child})
      : super(key: key);

  final Color color;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Theme(
      child: child,
      data: Theme.of(context).copyWith(
        primaryColor: color,
      ),
    );
  }
}