import 'package:flutter/material.dart';

class AJListItem extends StatelessWidget {


  final Widget leading;

  /// The primary content of the list tile.
  ///
  /// Typically a [Text] widget.
  final Widget title;

  /// Additional content displayed below the title.
  ///
  /// Typically a [Text] widget.
  final Widget subtitle;

  /// A widget to display after the title.
  ///
  /// Typically an [Icon] widget.
  final Widget trailing;

  final GestureTapCallback onTap;

  final EdgeInsetsGeometry padding;


  @override
  Widget build(BuildContext context) {
    return Container(
      padding: this.padding,
      decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Theme.of(context).dividerColor))),
      child:  new ListTile(
        leading: this.leading,
        title: this.title,
        subtitle: this.subtitle,
        trailing: this.trailing,
        onTap: this.onTap,),
    );
  }

  AJListItem({this.leading, this.title, this.subtitle, this.trailing, this.onTap, this.padding});
}