import 'package:flutter/material.dart';

class BaseScaffod extends StatefulWidget {
  final String title;
  final Widget childBuilder;
  BaseScaffod({this.title, this.childBuilder});

  @override
  _BaseScaffodState createState() => new _BaseScaffodState();
}

class _BaseScaffodState extends State<BaseScaffod> {

  @override
  void dispose() {
    super.dispose();
  }
  @override
  void initState() {
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(title: new Text(widget.title)),
      body: new Padding(
          padding: const EdgeInsets.all(8.0),
          child: new ListView(children: <Widget>[
            new SizedBox(height: 450.0, child: widget.childBuilder),
          ])),
    );
  }
}