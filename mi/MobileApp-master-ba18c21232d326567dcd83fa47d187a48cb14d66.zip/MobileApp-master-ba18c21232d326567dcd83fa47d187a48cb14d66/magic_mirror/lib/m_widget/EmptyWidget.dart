
import 'package:flutter/material.dart';
import 'package:magic_mirror/style/AJColors.dart';

class EmptyWidget extends StatelessWidget {

  final String emptyTitle;
//按钮事件
  final VoidCallback onPress;

  final double containH;
  EmptyWidget({this.emptyTitle, this.onPress, this.containH = 0});

  @override
  Widget build(BuildContext context) {

    return _buildEmpty(context);
  }

  ///空页面
  Widget _buildEmpty(context) {

    return new GestureDetector(
      onTap: (){
        this.onPress?.call();
      },
      child: new Container(
        height: this.containH > 0 ? this.containH :MediaQuery.of(context).size.height - 100,
        child: new Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            new Image(image: new AssetImage(AJICons.DEFAULT_REGISTER_ICON), width: 70.0, height: 70.0),
            Container(
              child: Text(emptyTitle ?? "目前什么也没有", style: AJConstant.normalText),
            ),
          ],
        ),
      ),
    );
  }

}