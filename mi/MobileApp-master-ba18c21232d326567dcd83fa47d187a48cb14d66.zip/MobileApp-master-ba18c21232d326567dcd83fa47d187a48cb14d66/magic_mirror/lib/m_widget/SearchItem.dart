import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:magic_mirror/m_widget/AJCardItem.dart';
import 'package:magic_mirror/style/AJColors.dart';

typedef SearchItemChangedCallback = void Function(int index);

class SearchItemWidget extends StatefulWidget{

  final double height;
  final int index;
  final String imageUrl;
  //项目名
  final String projectName;
  //项目环境
  final String projectEnv;
  final SearchItemChangedCallback itemOnChange;




  SearchItemWidget({this.index=0, this.height = 120.0, this.imageUrl, this.projectEnv, this.projectName, this.itemOnChange});

  @override
  State<StatefulWidget> createState() {
    return _SearchItemWidgetState();
  }

}

class _SearchItemWidgetState extends State<SearchItemWidget> {
  @override
  Widget build(BuildContext context) {


    Uint8List _base64;
    try{
       _base64 =  base64.decode(widget.imageUrl.substring(widget.imageUrl.indexOf(",") + 1));

    }catch(e){
       _base64 = base64.decode("iVBORw0KGgoAAAANSUhEUgAAAIwAAACMCAYAAACuwEE+AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyJpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoV2luZG93cykiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NjBENTlGMTBFM0YyMTFFOEE1QTdEODlCRUFFQThCQzQiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NjBENTlGMTFFM0YyMTFFOEE1QTdEODlCRUFFQThCQzQiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo2MEQ1OUYwRUUzRjIxMUU4QTVBN0Q4OUJFQUVBOEJDNCIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo2MEQ1OUYwRkUzRjIxMUU4QTVBN0Q4OUJFQUVBOEJDNCIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PvKHR1IAAA8VSURBVHja7F0LlFVlFd7DAAOjDCiIyEschBQIEx/4AAElXGW58tFSMkMqayWGsbJ8gEkrQ1wZZlRWpJmWJWUqkPmoVARSNJGXQMgbQUZeMjPyGGDa3zrfzcud+/jPvefec+6d/a31rZHxPs6c/zv733v/+99/WWNjoxgMrmhht8BggjGYYAwmGIMJxmCCMRhMMAYTjMEEYzDBGEwwBhOMwWCCMZhgDCYYgwnGYIIxmGAMBhOMwQRjMMEYTDAGE4zBYIJJd1+OUx5tt8IE4wII5UrlaXYrTDAu6Ky8XHm63Yoj0dJuQVKcqDxXuU7ZStlgt8QsTDr0Vx7Fn13sdphg0qGtcjD/u5+y2m6JCSYdhipH8r87KK9StrHbYoJJhhOU36HTG8MXlZfarTHBJAsArldemPD7dsrblX3tFplg4jFMOT7FPUE+5lvKChOMQejYTlJ2TPOa65TXmGAMA5UPKC9wiJ6mKr8pXm6mWaKsGfe4K6O/ci+nnDLH99Uq71P+WLnHBNM8AAtxmXKKsncW7z+ofFQ5UbnVBFPa6Ex/5BblsTl+1hzlD5RLlXtNMKUF5FiQkPuycniAn7tN+XvlY8rlyv0mmOIG1oIuUn5JOSqP37OBwvkLLc4hE0xx4WTlOeKl9j+lLC/Q965UzlT+Xfl2qTnGpSYY+CSoYRnBCGiQhJdsQ2nEPOW/lAuU/zXBRAd9aEUw9Zyh7Baha4MzvEz5ivI55UvKAyaYcIBCp6uVV4iXgIt66n6z8kXlHygeE0yB0FU5mmL5uBTfGs8W5QvKh2lxTDB5AoqzxyjHKk9VVhb5VPqu8lnlz5RvmWCCBWpsb6OfUuxCicdhOsgQzUNRj6qKQTBYQf6qcpyyu7iv+RQb4Ag/o7xHuZBCMsH4QDmtCoqXRknh8ihhY6Pyp7Q2u0wwbkAN7ReUdyp7SvPDYUZSk5VrTTCZp6AJZKU0b8yn34YEYKMJpilQN/t9hssGD7AwdyifkAgsbEZJMPBXUMx0nmmkCT4Qr9oPkVSdCUZkCG+GbX5PDWzXRZUfir5qm7NghlEsA0wTGYFKv/s5bYcimrCLwLGq/AsTizOwd2o8BdMurAsI07KgWv9jpgNfQD3yOEZN31PWNwcLA1/lJyaWrNGaormh0GMYhg+DWpUHlRfbuAcSPUE4j0mB8jSFtjDohoAq+0/aWAeC9sofcnovuSkJZhT7k8eI7bgMEigiu7dQgUMhB+4yCsbEEjxQlop1t6pSEQxS/rfRhBryA/SwQbuSsmIXDMonbxXL4hZiyr9JvK01kYiSYO6wzbSHeMU+O5Tv82c6oJxyunhNBg35B/ZDoTRkd5rXIJfTnUEItuag7mYLx7IhV8GcKd4en37kSRTMdvE2bc1S/lP5XpL3Is+CVdb+No4FA5YPsLo9Ncn/K6e/8znx2ptgV+gxyp3KVcoV4lX7YUfDHr+CwVyIyvyJFEoqYN/N88q7la8lvB9tMcZL/ssqsS21ltcCq7eP/lJ7muq2pBToOjBo9RyIQ3yKYaErpTA1Ptg0h8bUyxNSGuhtc614+7hSAdeNLb9Y5NzoKpgOHGiwo+NFLhGvI8Kz/DfKFf7IsC9ovEdx4qn4gCKp4VOxnYKp4t9RQeGgcm8g2UeC25oCU44tsYv5hMa+v46m/hCf4pj578Lr6UrrPTAPviQq9rBIeTP/G9+J9aeviHup6z/E68r1WibBVNCq3MKn0w8wRWHT++viZXPHBmhdPlS+Kt4+nrn8ru3ib9N7B/pgp4i3pRa7JT+RxbXspFXFdWBX43rx+sQc9PEZR1HEZ3HKR/KtV4Ci2UAr86Z4NcI3ZjEWb9EiLUsnmOHKp3IIgVGLik1akwO6Adi78yfx9igv4RMdREU9HoZqigatVQc5vAdO4ZPKPyv/4+Dw+xFyb0Y4l0vTTp7ZApUASzm9HJPlZ2CBGOWyXrUfBBPH9sqZjbmhVrlF2dCYO55WDlG2TbjOIFmu7K0cr3w7xXXsUz6ovEBZlcdrwQPcTXmrcmsA9+8D5fYAPuOi2DXGX2wL5dXKA43hY4NygrJTHgcnkS2VA5M8MGuVY5XtCngtrZVDlXMao4FZymMTBVOpfDzkCzusfFI5mAMoIfAY5UQ+mc8rz+LDFMa14IH5Li12mKilpT/ChzmeSZ+wzgiC8zqDOYTtIecy2nI5Yzt9qDBRRr8GUU9YbUwaGWH9Nr7iDkfWnRDSBR1mCH5nBMQSyy0tjkgirpHJT+Rvpik7hSRapAGOKNHs6ZBzQVQQ24nXQ4I7S2gOQ/kaS9SmxKNMefyIUVWuQJ5oDXNaFbSoXTO9KV4w1ZK+w/U8Zm7n8d9YTLyeaeZcOmPPZc5no2kiIx5kQhJJuFwOMF3JkHu2chNTDChqQzHWgDSW7gin9zo6ncmwTDkoiVPWQflwDs7UOuX5PkLOTiE6oPkk0hlHO762QvmbNGPlcs8vTPHZ45QHU7zvdrwmPiW9WlJXoMMZXpTk97u5hrQmSycX3SbnO7y2J/2bXzNd3aNELEZLOrS/5BPvUueMBNqvxOspk40/9ACToKmSpKky5y0SLUy1ck0KdSFp1SqFKvFkPJGF0lcx75HpieqlnJ3w3r/y98VsVVrzia6J+7s2Kq+iNc1kbaensQapUKc8O83n3pXmvTcnWphdkrxEAbiUawrJ0CoLz72RlmVZhtdVcAH0Mwm/R7nnOCnu7g5DmUI4Lu53sJx3ideOLdP9m5VFRNmK6ZNk+CzX/lJhnSSsktZzcS8ZOnHqmcbFsjZxofgNXHX1A6wwP+ewJlQlqXcYDJPiPvH13BSDh4bUgx3ev8DhgUu2fjaBnx8LeLpyYfK+NFESun+uSIySDjAX8vkUPgKq7W6iEtdw0LsxWvL7pK+Pi7bS4UN+14AUn7G7iAWDqHCfND2AtM7RP6nnPRwq/qoKRjBEX0l/6ERatHRR1+/+76cmzGHwU+4oQPr/EYd5OkakpFcnfAb+PdzHZ0SRiDBnJLk/U5VtHD/jYuWOPI/XEmWf2HcmFu6gnhO76BbmOYu6UNx36s1nvudF+lkv8N9zJSJdmbLEbiYr76bJh8VEP797aHlcsITvzSd+Hh8Fp6q4+7R4e5/75OEC4KhdqXzZ5/s6cs6vicjyQVDAdNJLvOKrzeK/rfxM3s+gy2APMo0Bx3xnskxvPJ7hMgDUj2LhTGV9jT4ueFuWeZsdElzBUpQAgeRycMU7zJ0E2YkDJa9TmbPZ2zQZkxyo5RxDlW2iCW1IEAlqaBenSOqlwlZekCEYLBf30tBaRldbk4xlPa33Ak750yTJKXOZVLmJIdf9jIZQxtiXQnufH/4yTaJLieNhRgf7bZwDQw2tVBuH166jGDozXdGH78NYovZ3Kf2i3elS0y6DvIqcGTc9HUrIq7gm7OpsjAPFLqYfXPZVw/dDcha7HF6KS+Y1uH5ZNtsbDknT9YYt4l69X2ZjHCjKfIzj7iSRZYOfLwtqP8wecTtVFX9cOxvjQIG9Tq6J0825ugNBCWaHuBU/4fu6SjM+WT4P6CDum9M2RkUwW31ESrHdiIZg0NlxHOsZUR2KgmDgeM13fC0WLHvaOAeG/o4WGxHQily/LCjBIJLCTsBtjk/EEBvnQICH70zHcVzgOD4FEQzwjuO0hD3Fw2ysAwHKFKodXge/BaUr+6IkmK3ifuAlknyn2njnjJHiln9ZJP6y8QURDOL72ZyaMgFNia4Ry8nkglj3iUwREtyFmZwBIiUYABnExx08cURJWE44w8Y9K0AkOAezt6Pv8nRQX5yPpojYpfe6w+vQzgzrGq1t/H0DJ+te5mBdsCiJVilroywYXBx6xLiknGFlRtv4+wKaGX5b3LY1Y2H4qSC/PF9tV1Eb/KTD65DWnmRhtjMQYWJ/1iiH12KREYXd7xaDYLBUgO2cLqe9o0p+Cn8aUiN2VtK1Dq9FuQMqJv8W9EXks7EzHODJ4lYsNZR/YF/TRVLEzmm4RdyWVRB4PJCPC8l3J/BZNIsuPekuEa+6b5Dp4wigwAmd1HGYlkvfwVf5oO4pRsEgNzOd1sNFNMgAz2AUYPBS/1NoWVzKQuACTJA8Ho5eqAO2kI3E4RQ3i1uV33rxDg7FpvPmWqGHQADbTpDNdVlcRML0Rkm9e7WoBAMczXDwdnHLvaDsEF0j7nJ0nksFuE9fE69rdy/H97yh/AZ/SqkIBqikpz9J3A6rwMWhDclD4m3v3FLiju1w8ZoMoEDbtdX9XE5DbxbiIsM48xE35grmExAVuawnIWO5hFMUMsm7JJjmzlEAppuzlV8Xr0tFB8d7gpJY7HnG/qENhbrYMA86P42iuUTclwcOco6OdRtHUmpfEYqknBEPIsKrxEvzd/TxfmwXwSbDR6TAW3bCFIzwpt3E+ddv6w7snpxNopoMW10ORFgkZfRP0PECreEvp2Prp1x1L6egyfl2bqMqmBhG0MPHT7898eEcz+eNxCZ/bDut4e+jYEmw/IGWGji15Hz6KdU+Pwer/yvox83glCzNWTAiH5U8oAvSeZLd+Ub1tDYLGWbCdKOwC0sVyfbkBI22FAjyJ+ixg3pbVMWhjLJ7lp+5ln4bOmiuCt1MRkgwMaBDA46gG82nMpcdBtuY04FwVtI53EYB1fNJraNv1CDpV9jL6aC25DXBEiKZVsVrxvaZk+nIn8SpJ5dDvTbRT3tY+Upk5tUICiaGvgwv0XrkXMn++JZ4HKZIYG1qKZ5d9A3qKZ69dCQb6HdUcOAr6YNUMiVwPK1JOzqsbQL6uxEN4nArdNCYJxHbhx5lwcRbnHMonJFZzP/FAPhbqIzD6jLOz1wmEW2WVAyCiQFP9QD6N7A4aM7Yq4hFUkdr8m867W9wGoo0ikkw8cAUgM1wpzM0hYD6iPuW0bCA7gmL6JMgLF5Np7xo2p8Uq2DiAacT5YqoEcbWlX60RL3oY4QFiGAzw/y3Gb2tZv5op/jsmmCCyQ9a0UmtYtQCq3NKXNQCx7kLHdU2knubLzjIyDTHDnyvYVS2miHwevnolNn9UtxNHEtSME3+PooCU1VrRjiwOu0poC45TGO1DNN3MtKKZZphOZL10CmNG1rigjEEjBZ2CwwmGIMJxmCCMZhgDCYYg8EEYzDBGEwwBhOMwQRjMMEYDCYYgwnGYIIxRBv/E2AAwteEqJE5brUAAAAASUVORK5CYII=");
    }
    return new Material(
      child: AJCardItem(
        child: new Column(
          children: <Widget>[
            new FlatButton(
                onPressed: (){
                  widget.itemOnChange(widget.index);
                },
                child: new Padding(
                  padding: new EdgeInsets.only(left: 0.0, top: 5.0, right: 0.0, bottom: 10.0),
                  child: new Row(
                    children: <Widget>[
                      ClipOval(child: SizedBox(child: Container(
                        color:Color(AJColors.primaryValue),
                        child: Center(child: Container(child: new Image.memory(
                          _base64,
                          fit: BoxFit.cover,
                        ), margin: EdgeInsets.all(10.0),),),
                      ), width: 55.0, height: 55.0,),),
                      new Container(width: 10.0),
                      new Column(
                        children: <Widget>[
                          new Text(widget.projectName ?? "", style: AJConstant.titleTextBold),
                          new Text(widget.projectEnv ?? "", style: AJConstant.subTextStyle)
                        ],
                      ),
                    ],
                  ),
                )),
            new Divider(height: 1.0),
          ],
        ),
        elevation: 0.0,
        margin: const EdgeInsets.all(0.0),
      ),
    );
  }
}