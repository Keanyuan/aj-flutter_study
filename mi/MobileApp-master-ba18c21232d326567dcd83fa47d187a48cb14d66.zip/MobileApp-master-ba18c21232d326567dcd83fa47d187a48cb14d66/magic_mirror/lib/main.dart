import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:magic_mirror/dao/UserDao.dart';
import 'package:magic_mirror/model/User.dart';
import 'package:magic_mirror/page/HomePage.dart';
import 'package:magic_mirror/page/LoginPage.dart';
import 'package:magic_mirror/page/WelcomePage.dart';
import 'package:magic_mirror/style/AJColors.dart';
import 'package:magic_mirror/tools/AJState.dart';
import 'package:magic_mirror/tools/Code.dart';
import 'package:magic_mirror/tools/HttpErrorEvent.dart';
import 'package:magic_mirror/tools/NavigatorUtils.dart';
import 'package:redux/redux.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:fluttertoast/fluttertoast.dart';


void main(){
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp,]);

  runApp(new MyApp());
}

class MyApp extends StatelessWidget {

  MyApp({Key key}) : super(key: key);

  final store = new Store<AJState>(
      appReducer,
      //初始化redux
      initialState: new AJState(
          userInfo: User.empty(),
          themeData: new ThemeData(
              primarySwatch: AJColors.primarySwatch,
              platform: TargetPlatform.iOS //滑动返回
          )
      )
  );

  @override
  Widget build(BuildContext context) {
    //在Redux中最核心的自然是组件，以及组件相关的事件与数据流方式
    return new StoreProvider(
      store: store,
      child: new StoreBuilder<AJState>(
        builder: (context, store){
          return new MaterialApp(
            debugShowCheckedModeBanner: false,
            theme: store.state.themeData,
            routes: {
              WelcomePage.sName: (context) {
                return WelcomePage();
              },
              HomePage.sName: (context) {
                ///通过 Localizations.override 包裹一层，
                return new AJLocalizations(
                  child: new HomePage(),
                );
              },
              LoginPage.sName: (context) {
                return new AJLocalizations(
                  child: new LoginPage(),
                );
              },
            },

          );
        },
      ),
    );
  }

}



class AJLocalizations extends StatefulWidget {
  final Widget child;
  AJLocalizations({Key key, this.child}) : super(key: key);

  @override
  State<AJLocalizations> createState() {
    return new _AJLocalizations();
  }
}

class _AJLocalizations extends State<AJLocalizations> {

  StreamSubscription stream;

  @override
  Widget build(BuildContext context) {

    //通过 StoreBuilder 和 Localizations 实现实时多语言切换  为多语言做准备
    return new StoreBuilder<AJState>(builder: (context, store){
      return new Localizations.override(
        context: context,
        child: widget.child,
      );
    });
  }

  @override
  void initState() {
    super.initState();
    //eventBus监听
    stream =  Code.eventBus.on<HttpErrorEvent>().listen((event) {
      errorHandleFunction(event.code, event.message);
    });
  }

  @override
  void dispose() {
    super.dispose();
    if(stream != null) {
      stream.cancel();
      stream = null;
    }
  }

  errorHandleFunction(int code, message) {
    switch (code) {
      case Code.NETWORK_ERROR:
        Fluttertoast.showToast(msg: "网络错误");
        break;
      case 401:
        Fluttertoast.showToast(msg: "未授权 \\ 授权登录失败 \\ 登录过期");
        break;
      case 403:
        Fluttertoast.showToast(msg: "权限错误");
        break;
      case 404:
        Fluttertoast.showToast(msg: "404错误");
        break;
      case Code.NETWORK_TIMEOUT:
      //超时
        Fluttertoast.showToast(msg: "请求超时");
        break;
      case Code.REQUEST_SHIBBOLETH://0104
        Fluttertoast.showToast(msg: "口令校验失败");
        Store<AJState> store = StoreProvider.of(context);
        UserDao.clearAll(store);
        NavigatorUtils.goLogin(context, result: true);
        break;
      default:
        Fluttertoast.showToast(msg: message);
        break;
    }
  }

}