class AppVersionModel  extends Object {
  bool isInfoShow;
  String paramDesc;
  String remark;
  AppVersionModel({
    this.isInfoShow = false,
    this.paramDesc = "",
    this.remark = ""
  });
}