import 'package:json_annotation/json_annotation.dart';


part 'GroupListModel.g.dart';

/// flutter packages pub run build_runner build
/// flutter packages pub run build_runner watch

@JsonSerializable()
class GroupListModel  extends Object {
  dynamic groupId;
  String groupName;

  GroupListModel(this.groupId, this.groupName);

  factory GroupListModel.fromJson(Map<String, dynamic> json) => _$GroupListModelFromJson(json);

}