// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'GroupListModel.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

GroupListModel _$GroupListModelFromJson(Map<String, dynamic> json) {
  return GroupListModel(json['groupId'], json['groupName'] as String);
}

Map<String, dynamic> _$GroupListModelToJson(GroupListModel instance) =>
    <String, dynamic>{
      'groupId': instance.groupId,
      'groupName': instance.groupName
    };
