import 'package:json_annotation/json_annotation.dart';


part 'HomeItemModel.g.dart';

/// flutter packages pub run build_runner build
/// flutter packages pub run build_runner watch

@JsonSerializable()
class HomeItemModel  extends Object {
  int projectId;
  int displayFlag;
  int sortValue;
  String projectName;
  String projectIcon;
  String projectDesc;
  String projectCode;


  HomeItemModel(this.projectId, this.displayFlag, this.sortValue,
      this.projectName, this.projectIcon, this.projectDesc, this.projectCode);

  factory HomeItemModel.fromJson(Map<String, dynamic> json) => _$HomeItemModelFromJson(json);

}