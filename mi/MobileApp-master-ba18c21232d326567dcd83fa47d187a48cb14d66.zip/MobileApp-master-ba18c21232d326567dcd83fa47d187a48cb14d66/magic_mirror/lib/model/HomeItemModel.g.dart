// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'HomeItemModel.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

HomeItemModel _$HomeItemModelFromJson(Map<String, dynamic> json) {
  return HomeItemModel(
      json['projectId'] as int,
      json['displayFlag'] as int,
      json['sortValue'] as int,
      json['projectName'] as String,
      json['projectIcon'] as String,
      json['projectDesc'] as String,
      json['projectCode'] as String);
}

Map<String, dynamic> _$HomeItemModelToJson(HomeItemModel instance) =>
    <String, dynamic>{
      'projectId': instance.projectId,
      'displayFlag': instance.displayFlag,
      'sortValue': instance.sortValue,
      'projectName': instance.projectName,
      'projectIcon': instance.projectIcon,
      'projectDesc': instance.projectDesc,
      'projectCode': instance.projectCode
    };
