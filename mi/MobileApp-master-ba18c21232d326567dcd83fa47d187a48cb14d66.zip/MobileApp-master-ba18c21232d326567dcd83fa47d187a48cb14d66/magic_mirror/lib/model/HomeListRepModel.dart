import 'package:json_annotation/json_annotation.dart';
import 'package:magic_mirror/model/HomeItemModel.dart';


part 'HomeListRepModel.g.dart';

/// flutter packages pub run build_runner build
/// flutter packages pub run build_runner watch

@JsonSerializable()
class HomeListRepModel  extends Object {
  int totalCount;
  int totalPage;
  int pageSize;
  int currentPage;
  List<HomeItemModel> list;

  HomeListRepModel(this.totalCount, this.totalPage, this.pageSize,
      this.currentPage, this.list);

  factory HomeListRepModel.fromJson(Map<String, dynamic> json) => _$HomeListRepModelFromJson(json);

}