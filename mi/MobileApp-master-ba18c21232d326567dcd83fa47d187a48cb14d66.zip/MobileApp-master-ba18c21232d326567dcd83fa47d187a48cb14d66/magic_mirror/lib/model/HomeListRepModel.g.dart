// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'HomeListRepModel.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

HomeListRepModel _$HomeListRepModelFromJson(Map<String, dynamic> json) {
  return HomeListRepModel(
      json['totalCount'] as int,
      json['totalPage'] as int,
      json['pageSize'] as int,
      json['currentPage'] as int,
      (json['list'] as List)
          ?.map((e) => e == null
              ? null
              : HomeItemModel.fromJson(e as Map<String, dynamic>))
          ?.toList());
}

Map<String, dynamic> _$HomeListRepModelToJson(HomeListRepModel instance) =>
    <String, dynamic>{
      'totalCount': instance.totalCount,
      'totalPage': instance.totalPage,
      'pageSize': instance.pageSize,
      'currentPage': instance.currentPage,
      'list': instance.list
    };
