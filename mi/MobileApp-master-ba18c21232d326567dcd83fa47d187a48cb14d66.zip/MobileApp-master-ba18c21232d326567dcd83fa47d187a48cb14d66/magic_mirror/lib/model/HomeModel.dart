import 'package:json_annotation/json_annotation.dart';


part 'HomeModel.g.dart';

/// flutter packages pub run build_runner build
/// flutter packages pub run build_runner watch

@JsonSerializable()
class HomeModel  extends Object {
  int id;
  String projectName;
  String icon;
  String description;

  HomeModel(this.id, this.projectName, this.icon, this.description);

  factory HomeModel.fromJson(Map<String, dynamic> json) => _$HomeModelFromJson(json);

}