// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'HomeModel.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

HomeModel _$HomeModelFromJson(Map<String, dynamic> json) {
  return HomeModel(json['id'] as int, json['projectName'] as String,
      json['icon'] as String, json['description'] as String);
}

Map<String, dynamic> _$HomeModelToJson(HomeModel instance) => <String, dynamic>{
      'id': instance.id,
      'projectName': instance.projectName,
      'icon': instance.icon,
      'description': instance.description
    };
