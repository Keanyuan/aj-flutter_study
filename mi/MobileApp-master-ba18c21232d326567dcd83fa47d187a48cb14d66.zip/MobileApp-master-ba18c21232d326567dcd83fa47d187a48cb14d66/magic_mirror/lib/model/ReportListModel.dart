import 'package:json_annotation/json_annotation.dart';

part 'ReportListModel.g.dart';

/// flutter packages pub run build_runner build
/// flutter packages pub run build_runner watch

@JsonSerializable()
class ReportListModel  extends Object {


  @JsonKey(name: 'currentPage')
  int currentPage;

  @JsonKey(name: 'pageSize')
  int pageSize;

  @JsonKey(name: 'chartId')
  int chartId;

  @JsonKey(name: 'chartType')
  String chartType;

  @JsonKey(name: 'chartName')
  String chartName;

  @JsonKey(name: 'tableName')
  String tableName;

  @JsonKey(name: 'projectId')
  int projectId;

  @JsonKey(name: 'calConfigId')
  int calConfigId;

  @JsonKey(name: 'defaultParticle')
  String defaultParticle;

  @JsonKey(name: 'particles')
  String particles;

  @JsonKey(name: 'groupByCalColumnId')
  int groupByCalColumnId;

  @JsonKey(name: 'groupId')
  int groupId;

  @JsonKey(name: 'groupName')
  String groupName;


  ReportListModel(this.currentPage,this.pageSize,this.chartId,this.chartType,this.chartName,this.tableName,this.projectId,this.calConfigId,this.defaultParticle,this.particles,this.groupByCalColumnId,this.groupId, this.groupName);

  factory ReportListModel.fromJson(Map<String, dynamic> json) => _$ReportListModelFromJson(json);

}