// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ReportListModel.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ReportListModel _$ReportListModelFromJson(Map<String, dynamic> json) {
  return ReportListModel(
      json['currentPage'] as int,
      json['pageSize'] as int,
      json['chartId'] as int,
      json['chartType'] as String,
      json['chartName'] as String,
      json['tableName'] as String,
      json['projectId'] as int,
      json['calConfigId'] as int,
      json['defaultParticle'] as String,
      json['particles'] as String,
      json['groupByCalColumnId'] as int,
      json['groupId'] as int,
      json['groupName'] as String);
}

Map<String, dynamic> _$ReportListModelToJson(ReportListModel instance) =>
    <String, dynamic>{
      'currentPage': instance.currentPage,
      'pageSize': instance.pageSize,
      'chartId': instance.chartId,
      'chartType': instance.chartType,
      'chartName': instance.chartName,
      'tableName': instance.tableName,
      'projectId': instance.projectId,
      'calConfigId': instance.calConfigId,
      'defaultParticle': instance.defaultParticle,
      'particles': instance.particles,
      'groupByCalColumnId': instance.groupByCalColumnId,
      'groupId': instance.groupId,
      'groupName': instance.groupName
    };
