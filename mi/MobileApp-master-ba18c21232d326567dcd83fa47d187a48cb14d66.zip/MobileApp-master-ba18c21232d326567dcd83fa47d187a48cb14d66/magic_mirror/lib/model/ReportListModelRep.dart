import 'package:json_annotation/json_annotation.dart';
import 'package:magic_mirror/model/ReportListModel.dart';


part 'ReportListModelRep.g.dart';

/// flutter packages pub run build_runner build
/// flutter packages pub run build_runner watch

@JsonSerializable()
class ReportListModelRep  extends Object {
  int totalCount;
  int currentPage;
  List<ReportListModel> list;

  ReportListModelRep(this.totalCount, this.list);

  factory ReportListModelRep.fromJson(Map<String, dynamic> json) => _$ReportListModelRepFromJson(json);

}