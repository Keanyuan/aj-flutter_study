// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ReportListModelRep.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ReportListModelRep _$ReportListModelRepFromJson(Map<String, dynamic> json) {
  return ReportListModelRep(
      json['totalCount'] as int,
      (json['list'] as List)
          ?.map((e) => e == null
              ? null
              : ReportListModel.fromJson(e as Map<String, dynamic>))
          ?.toList())
    ..currentPage = json['currentPage'] as int;
}

Map<String, dynamic> _$ReportListModelRepToJson(ReportListModelRep instance) =>
    <String, dynamic>{
      'totalCount': instance.totalCount,
      'currentPage': instance.currentPage,
      'list': instance.list
    };
