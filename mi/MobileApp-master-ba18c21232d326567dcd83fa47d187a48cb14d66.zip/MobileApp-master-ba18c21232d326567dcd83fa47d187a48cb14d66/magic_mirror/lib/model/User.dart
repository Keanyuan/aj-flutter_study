import 'package:json_annotation/json_annotation.dart';


part 'User.g.dart';

/// flutter packages pub run build_runner build
/// flutter packages pub run build_runner watch

@JsonSerializable()
class User  extends Object {
  int userId;
  String username;
  String email;
  String mobile;
  int userType;
  String token;
  List<dynamic> proArr;
  User(this.userId, this.username, this.email, this.mobile, this.userType,
      this.token);
  factory User.fromJson(Map<String, dynamic> json) => _$UserFromJson(json);
  Map<String, dynamic> toJson(User user) => _$UserToJson(user);
  User.empty();

}