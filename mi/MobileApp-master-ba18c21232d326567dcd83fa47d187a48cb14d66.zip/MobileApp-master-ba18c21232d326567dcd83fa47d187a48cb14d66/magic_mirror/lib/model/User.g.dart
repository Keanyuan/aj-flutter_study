// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'User.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

User _$UserFromJson(Map<String, dynamic> json) {
  return User(
      json['userId'] as int,
      json['username'] as String,
      json['email'] as String,
      json['mobile'] as String,
      json['userType'] as int,
      json['token'] as String)
    ..proArr = json['proArr'] as List;
}

Map<String, dynamic> _$UserToJson(User instance) => <String, dynamic>{
      'userId': instance.userId,
      'username': instance.username,
      'email': instance.email,
      'mobile': instance.mobile,
      'userType': instance.userType,
      'token': instance.token,
      'proArr': instance.proArr
    };
