import 'package:flutter/material.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:magic_mirror/dao/UserDao.dart';
import 'package:magic_mirror/m_widget/AJFlexButton.dart';
import 'package:magic_mirror/m_widget/AJInputWidget.dart';
import 'package:magic_mirror/style/AJColors.dart';
import 'package:magic_mirror/tools/AJState.dart';
import 'package:magic_mirror/tools/Code.dart';
import 'package:magic_mirror/tools/CommonUtils.dart';
import 'package:magic_mirror/tools/ResultData.dart';
import 'package:redux/redux.dart';

class ForgetPasswordPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return new _ForgetPasswordPageState();
  }
}
//用于使用到了一点点的动画效果，因此加入了SingleTickerProviderStateMixin
class _ForgetPasswordPageState extends State<ForgetPasswordPage>
    with SingleTickerProviderStateMixin {

  var _emailNum = "";
  var _password = "";
  var _captchatext = "";
  var _codeId = "";

  var _errorText = null;
  var _errorEmailNumText = null;


  _ForgetPasswordPageState() : super();

  final TextEditingController _emailNumController = new TextEditingController();
  final TextEditingController _pwController = new TextEditingController();

  @override
  void initState() {
    super.initState();
    initParams();
    _getCodeInfo();

  }

  initParams() async {
    _emailNumController.value = new TextEditingValue(text: _emailNum ?? "");
    _pwController.value = new TextEditingValue(text: _password ?? "");
  }

  _getCodeInfo() async{
    UserDao.getVerificationCode().then((res){
      if(res.result){
        var map = res.data;
        _captchatext = map["code"];
        _codeId = map["codeId"];
        setState(() {
        });
      }
    });
  }

  @override
  void dispose() {
    super.dispose();
    _emailNumController.dispose();
    _pwController.dispose();
  }

  _focusScopeCheck(){
    if(_captchatext != _password && _password.length != 0){
      _errorText = "验证码输入有误";
    } else {
      _errorText = null;
    }

    if(_emailNum.length != 0){
      if(!CommonUtils.isEmail(_emailNum)) {
        _errorEmailNumText = "邮箱格式有误";
      } else {
        _errorEmailNumText = null;
      }
    } else {
      _errorEmailNumText = null;
    }
    setState(() {
    });
  }

  @override
  Widget build(BuildContext context) {
    final heightScreen = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: Color(AJColors.white),
      appBar: new AppBar(
        title: Text("忘记密码"),
      ),
      body: GestureDetector(
        onTap: (){
          FocusScope.of(context).requestFocus(new FocusNode());
          _focusScopeCheck();
        },
        child: Container(
          color: Color(AJColors.white),
          height: heightScreen,
          margin: EdgeInsets.only(left: 30.0, right: 30.0),
          child: ListView(
            children: <Widget>[
              new SizedBox(height: 30.0),
              new Image(image: new AssetImage(AJICons.DEFAULT_REGISTER_ICON), height: 60.0,),
              new Padding(padding: new EdgeInsets.all(10.0)),
              new AJInputWidget(
                hintText: "请输入邮箱",
                errorText: _errorEmailNumText,
                iconData: AJICons.REGIST_EMAIL,
                onChanged: (String value){
                  _emailNum = value;
                  _focusScopeCheck();
                },
                onSubmitted: (v){
                  _focusScopeCheck();

                },
                controller: _emailNumController,
                fontSize: AJFont.TEXT_FIELD_FONT,
              ),
              new Padding(padding: new EdgeInsets.all(10.0)),
            Row(
//              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                Expanded(flex: 3,child: new AJInputWidget(
                  hintText: "请输入随机验证码",
                  iconData: AJICons.LOGIN_PW,
                  errorText: _errorText,
                  onChanged: (String value) {
                    _password = value;
                    _focusScopeCheck();
                  },
                  onSubmitted: (value){
                    _focusScopeCheck();
                    FocusScope.of(context).requestFocus(new FocusNode());
                  },
                  controller: _pwController,
                  fontSize: AJFont.TEXT_FIELD_FONT,
                )),
                Expanded(flex: 0,child: Container(
//                  margin: EdgeInsets.only(right: 5),
                  width: 1, height: 30, color: Color(AJColors.lightGray),),),
                Expanded(flex: 1,
                    child: RaisedButton(
                      materialTapTargetSize:MaterialTapTargetSize.shrinkWrap,

                      color: Color(AJColors.white),
                      textColor: Color(AJColors.primaryValue),
                      elevation: 0,
                      onPressed: (){
                        _getCodeInfo();
                      },
                      child: Text(_captchatext ?? "获取验证码", style: TextStyle(fontSize: 14),),
                    ),
                ),
              ],
            ),
              new Padding(padding: new EdgeInsets.all(30.0)),
              new AJFlexButton(
                text: "发送",
                color: AJColors.BLUE_COLOE,
                textColor: Color(AJColors.textWhite),
                radius: 30.0,
                onPress: ()async{

                  if (_emailNum == null || _emailNum.length == 0) {
//                            CommonUtils.showDialogAlert(context, '请输入用户名');

                    new ResultData(Code.errorHandleFunction(1001, '请输入邮箱', false), false, 1001);

                    return;
                  }
                  if(!CommonUtils.isEmail(_emailNum)){
                    new ResultData(Code.errorHandleFunction(1001, '请输入正确的邮箱', false), false, 1001);

                    return;
                  }
                  if (_password == null || _password.length == 0) {
//                            CommonUtils.showDialogAlert(context, '请输入密码');
                    new ResultData(Code.errorHandleFunction(1002, '请输入验证码', false), false, 1002);

                    return;
                  }
                  if(_captchatext == null){
                    new ResultData(Code.errorHandleFunction(1002, '请重新获取验证码', false), false, 1002);
                    return;
                  }

                  Store<AJState> store = StoreProvider.of(context);
                  CommonUtils.showLoadingDialog(context);
                  //email, verificationCode, codeId
                  UserDao.getMirrorAccessUserSendMail(_emailNum.trim(), _password.trim(), _codeId, store).then((res){
                    Navigator.pop(context);
                    if (res != null && res.result) {
                      new Future.delayed(const Duration(seconds: 1), () {
                        CommonUtils.dialogEmailPrompt(context);
                        return true;
                      });
                    }
                  });



                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}