import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:magic_mirror/dao/UserDao.dart';
import 'package:magic_mirror/m_widget/EmptyWidget.dart';
import 'package:magic_mirror/m_widget/HomeItemWidget.dart';
import 'package:magic_mirror/model/GroupListModel.dart';
import 'package:magic_mirror/model/HomeItemModel.dart';
import 'package:magic_mirror/model/HomeListRepModel.dart';
import 'package:magic_mirror/style/AJColors.dart';
import 'package:magic_mirror/tools/AJState.dart';
import 'package:magic_mirror/tools/CommonUtils.dart';
import 'package:magic_mirror/tools/NavigatorUtils.dart';
import 'package:magic_mirror/m_widget/AJListState.dart';

class HomePage extends StatefulWidget {
  static final String sName = "home";
  final bool isCheck;
  HomePage({this.isCheck = true});

  @override
  State<StatefulWidget> createState() {
    return _HomePageState();
  }

}



class _HomePageState extends AJListState<HomePage> {

//  var _searchText = "";
  var text1 = "魔镜窥见";
  var text2 = "—— 大数据实时监控利器";
  int indexPage = 1;
  int totalCount = 0;
  List<String> wallpapersList = List();
  bool isPullDown = true;
  String _searchText = "请搜索项目";
  List<HomeItemModel> dataList;

  @override
  void initState() {
    super.initState();
    CommonUtils.checkVersion(context);
    _requestHomeData();
    setState(() {
    });
  }





  @override
  void didChangeDependencies() {
    super.didChangeDependencies();


  }

  @override
  void dispose(){
    super.dispose();
  }


  Widget _buildTopWidget(context, widthSrcreen, heightScreen, h){
    return  new Container(
      width: widthSrcreen,
      height: h,
      decoration: new BoxDecoration(image: new DecorationImage(image: new ExactAssetImage(AJICons.HOME_TOP_BG), fit: BoxFit.cover)),
//      foregroundDecoration: new BoxDecoration(image: new DecorationImage(image: AssetImage(AJICons.HOME_TOP_BG), fit: BoxFit.fill,)),
      child: Container(child: Column(
        children: <Widget>[
          Padding(padding: new EdgeInsets.all(20.0)),
          _searchView(context, widthSrcreen, heightScreen, h),
          Container(
            margin: EdgeInsets.only(top: 30.0, left: 20.0),
            alignment: Alignment.topLeft,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(" \"$text1\" ", style: TextStyle(color: Color(AJColors.white), fontSize: 18.0),),
                Text(" $text2", style: TextStyle(color: Color(AJColors.white)),)

              ],
            ),
          )

        ],
      ),),
    );
  }

  Widget _searchView(context, widthSrcreen, heightScreen, h){
    final double searchH = 40.0;
    return new Container(
      width: widthSrcreen,
      height: searchH,
      child: new Row(
        children: <Widget>[
          SizedBox(width: 23.0,),
          new GestureDetector(
            onTap: (){
              //todo 点击搜索
              NavigatorUtils.gotoSearchPage(context, _searchText == "请搜索项目" ? "" : _searchText).then((value){
                setState(() {
                  if(value == null || value == ""){
                    _searchText = "请搜索项目";
                  } else {
                    _searchText = value;
                  }
                });
              });

              ///ChatScreenPageState
//              Navigator.push(context, new MaterialPageRoute(
//                  builder: (context) => new ChatScreenPage()),
//              );
            },
            child: Container(
              width: widthSrcreen - 40.0 - 23.0,
              height: searchH,
              decoration: new BoxDecoration(
                color: Color.fromRGBO(244, 244, 244, 0.5),
                borderRadius: new BorderRadius.all(new Radius.circular(searchH * 0.5)),
              ),
              child: Row(
                children: <Widget>[
                  SizedBox(width: 10.0,),
                  Container(
                    width: 40.0,
                    height: 40.0,
                    child: new Image.asset(AJICons.HOME_ICON_SEARCH, width: 20.0, height: 20.0,),
                    alignment: Alignment.center,
                  ),
                  Container(
                    child: new Text(_searchText, style: TextStyle(color: Color(AJColors.white), fontSize: 16.0), overflow: TextOverflow.ellipsis),
                  ),
                ],
              ),
            ),
          ),

          new GestureDetector(
            onTap: (){
              //TODO 退出
              return CommonUtils.dialogExitLoginApp(context);
            },
            child: new Container(
              width: 40.0,
              height: 40.0,
              alignment: Alignment.center,
              child: new Image.asset(AJICons.HOME_EXIT, width: 20.0, height: 20.0,),
            ),
          )
        ],
      ),
    );
  }

  Widget _buildBottomWidget(context, widthSrcreen, heightScreen, h){
    var width = (widthSrcreen - 21.0) / 3;
    var height = width;
    var heightT = h;
    if(widthSrcreen > heightScreen) {
      heightT = widthSrcreen;
    }

    Widget _widget = Center(child: SpinKitRipple(color: Color(AJColors.primaryValue), size: 150.0,),);
    if(dataList != null){
      if(dataList.length == 0 ){
        _widget = Center(child: EmptyWidget(
          emptyTitle: "暂无数据,请点击重试",
          onPress: ()async{
            dataList = null;
            _requestHomeData();
            setState(() {
            });
          },
        ),);
      } else {
        _widget = Card(
          margin: EdgeInsets.all(16.0),
          child: GridView.count(
            crossAxisCount: 3,
            padding: EdgeInsets.all(0.0),
            children: List.generate( this.dataList.length, (index) {
              return new HomeItemWidget(
                width: width,
                height: height,
//                imageUrl: Address.host + "assets/img/home/"+ this.dataList[index].projectIcon,
                imageUrl: this.dataList[index].projectIcon ?? "",
                index: index,
                projectName: this.dataList[index].projectName ?? "",
                projectEnv: this.dataList[index].projectDesc ?? "",
                itemOnChange: (index){
                  //TODO 跳转详情 暂无接口
//                  _checkVersion();
                  _gotoDetailList(this.dataList[index].projectId ?? 0, this.dataList[index].projectName ?? "");
                },
              );
            },
            ),
          ),
        );
      }
    }


    return Container(
//      color: Color(AJColors.white),
      height: heightT,
      child: _widget,
    );
  }

  @override
  Widget build(BuildContext context) {
    final heightScreen = MediaQuery.of(context).size.height;
    final widthSrcreen = MediaQuery.of(context).size.width;
    final double h1 = widthSrcreen * 406 / 750;
    final double h2 = heightScreen - h1;

    return new StoreBuilder<AJState>(
        builder: (context, store){
          return WillPopScope(
            child: Container(
              width: widthSrcreen,
              height: heightScreen,
              color: Color(AJColors.primaryValue),
              child: new Material(
                child: new CustomScrollView(
                  slivers: <Widget>[
                    SliverList(
                      delegate: SliverChildListDelegate( [
                        _buildTopWidget(context, widthSrcreen, heightScreen, h1),
                        _buildBottomWidget(context, widthSrcreen, heightScreen, h2),
                      ] ),
                    ),
                  ],
                ),
              ),
            ),
            onWillPop: (){
              CommonUtils.dialogExitApp(context);
            },
          );
        });
  }
  _requestHomeData(){
    UserDao.getSelectByPage(indexPage, 50, null).then((res){
      if (res != null && res.result){
        HomeListRepModel rep = res.data;
        if (rep.list.length > 0){
          if(indexPage == 1){dataList = List();}
          totalCount = rep.totalCount;
          dataList.addAll(rep.list);
          if (dataList.length >=  totalCount){ //没有更多数据
          } else { //有更多数据
            indexPage ++;
            _requestHomeData();
          }
        }
      } else {
        dataList = List();
      }
      setState(() {});
    });
  }

  _gotoDetailList(projectId, title){
    CommonUtils.showLoadingDialog(context);
    UserDao.queryGroupList(projectId).then((res){
      Navigator.pop(context);
      if (res != null && res.result){
        List<GroupListModel> groupList = [];
        if(res.data != null){
          groupList = res.data;
        }
        if(groupList.length > 1){
          NavigatorUtils.gotoReportHomePage(context, groupList, title, projectId);
        } else {
          NavigatorUtils.gotoReportListPage(context, projectId, title);
        }
      }else {
        NavigatorUtils.gotoReportListPage(context, projectId, title);
      }
    });
  }



  @override
  bool get wantKeepAlive => true;




}


