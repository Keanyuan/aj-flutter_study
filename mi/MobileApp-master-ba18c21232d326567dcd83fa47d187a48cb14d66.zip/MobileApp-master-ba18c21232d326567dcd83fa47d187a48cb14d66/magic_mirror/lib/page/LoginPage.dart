
import 'dart:convert';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:magic_mirror/dao/UserDao.dart';
import 'package:magic_mirror/m_widget/AJFlexButton.dart';
import 'package:magic_mirror/m_widget/AJInputWidget.dart';
import 'package:magic_mirror/model/AppVersionModel.dart';
import 'package:magic_mirror/style/AJColors.dart';
import 'package:magic_mirror/tools/AJState.dart';
import 'package:magic_mirror/tools/Code.dart';
import 'package:magic_mirror/tools/CommonUtils.dart';
import 'package:magic_mirror/tools/Config.dart';
import 'package:magic_mirror/tools/LocalStorage.dart';
import 'package:magic_mirror/tools/NavigatorUtils.dart';
import 'package:magic_mirror/tools/ResultData.dart';
import 'package:redux/redux.dart';

class LoginPage extends StatefulWidget{
  //login
  static final String sName = "login";

  @override
  State<StatefulWidget> createState() {
    return _LoginPageState();
  }

}


class _LoginPageState extends State<LoginPage>{

  var _userName = "";
  var _password = "";

  FocusNode _loginFocusNode = new FocusNode();
  FocusNode _passwordFocusNode = new FocusNode();


  _LoginPageState() : super();

  final TextEditingController userController = new TextEditingController();
  final TextEditingController pwController = new TextEditingController();

  @override
  void initState() {
    super.initState();
    initParams();
    CommonUtils.checkVersion(context);
  }


  initParams() async {
    _userName = await LocalStorage.get(AJConfig.USER_NAME_KEY);
    _password = await LocalStorage.get(AJConfig.PW_KEY);
    userController.value = new TextEditingValue(text: _userName ?? "");
    pwController.value = new TextEditingValue(text: _password ?? "");
  }


  @override
  Widget build(BuildContext context) {
    final heightScreen = MediaQuery.of(context).size.height;
    final widthSrcreen = MediaQuery.of(context).size.width;
    final double h1 = widthSrcreen *704 / 750;
    final double h2 = heightScreen - h1;
    return StoreBuilder<AJState>(
      builder: (context, store){
        return Scaffold(body: new GestureDetector(
          //冲击测试行为: 半透明的
          behavior: HitTestBehavior.translucent,
          onTap: (){
            //隐藏键盘
            FocusScope.of(context).requestFocus(new FocusNode());
          },
          child: WillPopScope(
            child: buildPageWidget(context, store, widthSrcreen, heightScreen, h1, h2),
            onWillPop: (){
              CommonUtils.dialogExitApp(context);
            },
          ),
        ),);
      },
    ) ;
  }


  Widget buildPageWidget(context, store, widthSrcreen, heightScreen, h1, h2){
    return new CustomScrollView(
      slivers: <Widget>[
        SliverList(
          delegate: SliverChildListDelegate( [
            Container(child: Image.asset(
                AJICons.DEFAULT_USER_BG_ICON,
                fit: BoxFit.cover,
                width: widthSrcreen,
                height: h1
            )),
            new AJInputWidget(
              margin: EdgeInsets.symmetric(horizontal: 20.0),
              hintText: "用户名",
              iconData: AJICons.LOGIN_USER,
              textInputAction: TextInputAction.next,
              focusNode: _loginFocusNode,
              onSubmitted: (value){
                _loginFocusNode.unfocus();
                FocusScope.of(context).requestFocus(_passwordFocusNode);
              },
              onChanged: (String value){
                _userName = value;
              },
              controller: userController,
              fontSize: AJFont.TEXT_FIELD_FONT,
            ),

            new Padding(padding: new EdgeInsets.all(10.0)),
            new AJInputWidget(
              margin: EdgeInsets.symmetric(horizontal: 20.0),
              hintText: "密码",
              iconData: AJICons.LOGIN_PW,
              obscureText: true,
              enableInteractiveSelection: false,
              textInputAction: TextInputAction.done,
              focusNode: _passwordFocusNode,
              onSubmitted: (value){
                FocusScope.of(context).requestFocus(new FocusNode());
                _logoin();
              },
              onChanged: (String value) {
                _password = value;
              },
              controller: pwController,
              fontSize: AJFont.TEXT_FIELD_FONT,
            ),
            new Padding(padding: new EdgeInsets.only(left: 20.0, right: 20.0, top: 40.0), child: new AJFlexButton(
              text: "登录",
              color: AJColors.BLUE_COLOE,
              textColor: Color(AJColors.textWhite),
              radius: 30.0,
              onPress: _logoin,
            ),),
            new Padding(padding: EdgeInsets.only(top: 10),
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: <Widget>[
                  new RawMaterialButton(
                    onPressed: (){
                      NavigatorUtils.gotoRegisterPage(context).then((value){
                        if(value != null){
                          if(value){
                            setState(() {
                              initParams();
                            });
                          }
                        }
                      });
                    },
//                    fillColor: Colors.green,
                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    constraints: const BoxConstraints(minWidth: 0.0, minHeight: 30.0),
                    child: new Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        new Text("没有账号？",style: TextStyle(color: Color(AJColors.primaryDarkValue)),),
                        new Text("马上注册", style: TextStyle(color: AJColors.BLUE_COLOE, decoration: TextDecoration.underline),),
                      ],
                    ),
                  ),
                  RawMaterialButton(
                    onPressed: (){
                      NavigatorUtils.gotoForgetPasswordPage(context);
                    },
                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
//                    fillColor: Colors.red,
                    constraints: const BoxConstraints(minWidth: 0.0, minHeight: 30.0),
                    child: new Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: <Widget>[
                        new Text("        ",style: TextStyle(color: Color(AJColors.primaryDarkValue)),),
                        new Text("忘记密码？", style: TextStyle(color: AJColors.BLUE_COLOE, decoration: TextDecoration.underline),),
                      ],
                    ),
                  )
                ],),
            ),

//            new Padding(padding: EdgeInsets.only(top: 10.0), child: RawMaterialButton(
//              onPressed: (){
//                NavigatorUtils.gotoForgetPasswordPage(context);
//              },
//              materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
//              fillColor: Colors.red,
//              constraints: const BoxConstraints(minWidth: 0.0, minHeight: 0.0),
//              child: new Row(
//                mainAxisAlignment: MainAxisAlignment.spaceAround,
//                children: <Widget>[
//                  new Text("        ",style: TextStyle(color: Color(AJColors.primaryDarkValue)),),
//                  new Text("忘记密码？", style: TextStyle(color: AJColors.BLUE_COLOE, decoration: TextDecoration.underline),),
//                ],
//              ),
//            ),),
//
//            new Padding(padding: new EdgeInsets.all(10.0)),
//            new RawMaterialButton(
//              onPressed: (){
//                NavigatorUtils.gotoRegisterPage(context);
//              },
//              fillColor: Colors.green,
//              materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
//              constraints: const BoxConstraints(minWidth: 0.0, minHeight: 0.0),
//              child: new Row(
//                mainAxisAlignment: MainAxisAlignment.center,
//                children: <Widget>[
//                  new Text("没有账号？",style: TextStyle(color: Color(AJColors.primaryDarkValue)),),
//                  new Text("马上注册", style: TextStyle(color: AJColors.BLUE_COLOE, decoration: TextDecoration.underline),),
//                ],
//              ),
//            ),
          ] ),
        ),
      ],
    );
  }


  _logoin()async{

    Store<AJState> store = StoreProvider.of(context);

    if (_userName == null || _userName.length == 0) {
//                            CommonUtils.showDialogAlert(context, '请输入用户名');

      new ResultData(Code.errorHandleFunction(1001, '请输入用户名', false), false, 1001);

      return;
    }
    if (_password == null || _password.length == 0) {
//                            CommonUtils.showDialogAlert(context, '请输入密码');
      new ResultData(Code.errorHandleFunction(1002, '请输入密码', false), false, 1002);

      return;
    }

    CommonUtils.showLoadingDialog(context);
    UserDao.getMirrorLogin(_userName.trim(), _password.trim(), store).then((res){
      Navigator.pop(context);
      if (res != null && res.result) {
        new Future.delayed(const Duration(seconds: 1), () {
          LocalStorage.save(AJConfig.USER_NAME_KEY, _userName);
          LocalStorage.save(AJConfig.PW_KEY, _password);
          NavigatorUtils.goHome(context);
          return true;
        });
      }
    });

//                          CommonUtils.showLoadingDialog(context);
//                          UserDao.getLoginDao(_userName.trim(), _password.trim(), store).then((res ){
//                            Navigator.pop(context);
//                            if (res != null && res.result) {
//                              new Future.delayed(const Duration(seconds: 1), () {
//                                NavigatorUtils.goHome(context);
//                                return true;
//                              });
//                            }
//                          });
//                          UserDao.getProjectQuery(1, 10).then((res ){});
//                          UserDao.getChartsByProject(1, 10, "32").then((res ){});

//                          NavigatorUtils.goHome(context);
  }

}
