import 'package:flutter/material.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:magic_mirror/dao/UserDao.dart';
import 'package:magic_mirror/m_widget/AJFlexButton.dart';
import 'package:magic_mirror/m_widget/AJInputWidget.dart';
import 'package:magic_mirror/style/AJColors.dart';
import 'package:magic_mirror/tools/AJState.dart';
import 'package:magic_mirror/tools/Code.dart';
import 'package:magic_mirror/tools/CommonUtils.dart';
import 'package:magic_mirror/tools/Config.dart';
import 'package:magic_mirror/tools/LocalStorage.dart';
import 'package:magic_mirror/tools/NavigatorUtils.dart';
import 'package:magic_mirror/tools/ResultData.dart';
import 'package:redux/redux.dart';

class RegisterPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return new _RegistPagerState();
  }
}
//用于使用到了一点点的动画效果，因此加入了SingleTickerProviderStateMixin
class _RegistPagerState extends State<RegisterPage>
    with SingleTickerProviderStateMixin {

  var _userName = "";
  var _phoneNum = "";
  var _emailNum = "";
  var _password = "";
  var _passwordres = "";

  var _errorUserNameText = null;

  var _errorPhoneNumText = null;

  var _errorEmailNumText = null;

  _RegistPagerState() : super();

  final TextEditingController _userController = new TextEditingController();
  final TextEditingController _phoneNumController = new TextEditingController();
  final TextEditingController _emailNumController = new TextEditingController();
  final TextEditingController _passwordresController = new TextEditingController();

  final TextEditingController _pwController = new TextEditingController();

  @override
  void initState() {
    super.initState();
    initParams();
  }

  initParams() async {
    _userController.value = new TextEditingValue(text: _userName ?? "");
    _phoneNumController.value = new TextEditingValue(text: _phoneNum ?? "");
    _emailNumController.value = new TextEditingValue(text: _emailNum ?? "");
    _pwController.value = new TextEditingValue(text: _password ?? "");
    _passwordresController.value = new TextEditingValue(text: _passwordres ?? "");
  }

  @override
  void dispose() {
    super.dispose();
    _userController.dispose();
    _phoneNumController.dispose();
    _emailNumController.dispose();
    _pwController.dispose();
    _passwordresController.dispose();

  }



  _focusScopeCheck(){
    if(_emailNum.length != 0){
      if(!CommonUtils.isEmail(_emailNum)) {
        _errorEmailNumText = "邮箱格式有误";
      } else {
        _errorEmailNumText = null;
      }
    } else {
      _errorEmailNumText = null;
    }
    setState(() {
    });
  }


  _focusScopeCheckPhoneNum(){
    if(_phoneNum.length != 0){
      if(!CommonUtils.isChinaPhoneLegal(_phoneNum)) {
        _errorPhoneNumText = "手机号输入有误";
      } else {
        _errorPhoneNumText = null;
      }
    } else {
      _errorPhoneNumText = null;
    }
    setState(() {
    });
  }

  _focusScopeCheckUserName(){
    if(_userName.length != 0){
      if(CommonUtils.isChineseCharacter(_userName)) {
        _errorUserNameText = "用户名不支持中文";
      } else {
        _errorUserNameText = null;
      }
    } else {
      _errorUserNameText = null;
    }
    setState(() {
    });
  }



  @override
  Widget build(BuildContext context) {
    final heightScreen = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: Color(AJColors.white),
      appBar: new AppBar(
        title: Text("注册"),
        actions: <Widget>[
          GestureDetector(
            child: Container(width: 80.0,height: 40.0,color: Color(AJColors.primaryValue),),
            onLongPress: (){
              NavigatorUtils.gotoHostConfigPage(context);
            },
          )
        ],
      ),
      body: GestureDetector(
        onTap: (){
          FocusScope.of(context).requestFocus(new FocusNode());
        },
        child: Container(
          color: Color(AJColors.white),
          height: heightScreen,
          margin: EdgeInsets.only(left: 30.0, right: 30.0),
          child: ListView(
            children: <Widget>[
              new SizedBox(height: 5.0),
              new Image(image: new AssetImage(AJICons.DEFAULT_REGISTER_ICON), height: 60.0,),
              new Padding(padding: new EdgeInsets.all(10.0)),
              new AJInputWidget(
                hintText: "请输入用户名",
                errorText: _errorUserNameText,
                helperText: "用户名只包含字母、数字或下划线等字符",
                iconData: AJICons.LOGIN_USER,
                onChanged: (String value){
                  _userName = value;
                  _focusScopeCheckUserName();
                },
                controller: _userController,
                fontSize: AJFont.TEXT_FIELD_FONT,
              ),
              new Padding(padding: new EdgeInsets.all(10.0)),
              new AJInputWidget(
                hintText: "请输入手机号",
                errorText: _errorPhoneNumText,
                iconData: AJICons.REGIST_PHONE_NUM,
                onChanged: (String value){
                  _phoneNum = value;
                  _focusScopeCheckPhoneNum();
                },
                controller: _phoneNumController,
                fontSize: AJFont.TEXT_FIELD_FONT,
              ),
              new Padding(padding: new EdgeInsets.all(10.0)),
              new AJInputWidget(
                hintText: "请输入邮箱",
                errorText: _errorEmailNumText,
                iconData: AJICons.REGIST_EMAIL,
                onChanged: (String value){
                  _emailNum = value;
                  _focusScopeCheck();
                },
                controller: _emailNumController,
                fontSize: AJFont.TEXT_FIELD_FONT,
              ),
              new Padding(padding: new EdgeInsets.all(10.0)),
              new AJInputWidget(
                hintText: "请输入密码",
                iconData: AJICons.LOGIN_PW,
                obscureText: true,
                onChanged: (String value) {
                  _password = value;
                },
                controller: _pwController,
                fontSize: AJFont.TEXT_FIELD_FONT,
              ),
              new Padding(padding: new EdgeInsets.all(10.0)),

              new AJInputWidget(
                hintText: "请再次确认密码",
                iconData: AJICons.LOGIN_PW,
                obscureText: true,
                onChanged: (String value) {
                  _passwordres = value;
                },
                controller: _passwordresController,
                fontSize: AJFont.TEXT_FIELD_FONT,
              ),
              new Padding(padding: new EdgeInsets.all(30.0)),
              new AJFlexButton(
                text: "注册",
                color: AJColors.BLUE_COLOE,
                textColor: Color(AJColors.textWhite),
                radius: 20.0,
                onPress: ()async{
                  _userName = _userName.trim();
                  if (_userName == null || _userName.length == 0) {
//                            CommonUtils.showDialogAlert(context, '请输入用户名');

                    new ResultData(Code.errorHandleFunction(1001, '请输入用户名', false), false, 1001);

                    return;
                  }
                  if (_phoneNum == null || _phoneNum.length == 0) {
//                            CommonUtils.showDialogAlert(context, '请输入密码');
                    new ResultData(Code.errorHandleFunction(1002, '请输入手机号', false), false, 1002);

                    return;
                  }

                  if (_emailNum == null || _emailNum.length == 0) {
//                            CommonUtils.showDialogAlert(context, '请输入用户名');

                    new ResultData(Code.errorHandleFunction(1001, '请输入邮箱', false), false, 1001);

                    return;
                  }
                  if (_password == null || _password.length == 0) {
//                            CommonUtils.showDialogAlert(context, '请输入密码');
                    new ResultData(Code.errorHandleFunction(1002, '请输入密码', false), false, 1002);

                    return;
                  }
                  if (_passwordres == null || _passwordres.length == 0) {
//                            CommonUtils.showDialogAlert(context, '请输入用户名');

                    new ResultData(Code.errorHandleFunction(1001, '请输入确认密码', false), false, 1001);

                    return;
                  }

                  if(CommonUtils.isChineseCharacter(_userName)) {
                    new ResultData(Code.errorHandleFunction(1001, '用户名不支持中文', false), false, 1001);
                    return;
                  }

                  if(!CommonUtils.isChinaPhoneLegal(_phoneNum)){
                    new ResultData(Code.errorHandleFunction(1001, '请输入正确的手机号', false), false, 1001);

                    return;
                  }


                  if(!CommonUtils.isEmail(_emailNum)){
                    new ResultData(Code.errorHandleFunction(1001, '请输入正确的邮箱', false), false, 1001);

                    return;
                  }
                  if(_password != _passwordres){
                    new ResultData(Code.errorHandleFunction(1001, '两次密码输入不正确', false), false, 1001);

                    return;
                  }

                  if(_password.length < 6){
                    new ResultData(Code.errorHandleFunction(1001, '密码长度必须大于6位', false), false, 1001);
                    return;
                  }



                  Store<AJState> store = StoreProvider.of(context);
                  CommonUtils.showLoadingDialog(context);
                  UserDao.getMirrorCreateOrUpdateUser(_userName.trim(), _phoneNum.trim(), _emailNum.trim(), _password, _passwordres, store).then((res){
                    Navigator.pop(context);
                    if (res != null && res.result) {
                      new ResultData(Code.errorHandleFunction(Code.SUCCESS, "注册成功，请登录", false), false, Code.SUCCESS);
                      new Future.delayed(const Duration(seconds: 1), () {
                        LocalStorage.save(AJConfig.USER_NAME_KEY, _userName);
                        LocalStorage.save(AJConfig.PW_KEY, _password);
                        Navigator.pop(context, true);
                        return true;
                      });
                    }
                  });

                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}