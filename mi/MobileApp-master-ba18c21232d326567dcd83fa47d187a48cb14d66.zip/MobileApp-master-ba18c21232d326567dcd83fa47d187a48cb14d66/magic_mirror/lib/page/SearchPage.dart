import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:magic_mirror/dao/UserDao.dart';
import 'package:magic_mirror/m_widget/AJCardItem.dart';
import 'package:magic_mirror/m_widget/EmptyWidget.dart';
import 'package:magic_mirror/m_widget/SearchItem.dart';
import 'package:magic_mirror/model/HomeItemModel.dart';
import 'package:magic_mirror/model/HomeListRepModel.dart';
import 'package:magic_mirror/request/Address.dart';
import 'package:magic_mirror/style/AJColors.dart';
import 'package:magic_mirror/tools/Config.dart';
import 'package:magic_mirror/tools/LocalStorage.dart';
import 'package:magic_mirror/tools/NavigatorUtils.dart';


class SearchPage extends StatefulWidget {
  final String editText;

  SearchPage({this.editText});

  @override
  State<SearchPage> createState() {
    return _SearchState();
  }
}

class _SearchState extends State<SearchPage> with SingleTickerProviderStateMixin {
  String testTxt = '我是士大夫!';
  Tween<int> tween;
  AnimationController animationController;
  Animation<int> animation;
  String text;
  List<HomeItemModel> dataList = [];
  int indexPage = 1;
  int totalCount = 0;
  var _searchText = "";

  final TextEditingController _searchController = new TextEditingController();


  List<String> mHostory;



  @override
  void initState() {
    super.initState();
    _searchController.value = new TextEditingValue(text: _searchText ?? "");

    animationController =
    new AnimationController(vsync: this, duration: Duration(seconds: 1));

    animation = IntTween(begin: 0, end: testTxt.length).animate(
        CurvedAnimation(parent: animationController, curve: Curves.easeIn));

    mHostory = new List();

    _getHostoryData();


    animation.addListener(() {
      setState(() {
        text = testTxt.substring(0, animation.value);
      });
    });

    animationController.forward(from: 0.0);
    setState(() {

    });
//    _searchProjectName();

  }

  _getHostoryData()async{
    var historyData = await LocalStorage.get(AJConfig.SEARCH_HOSTORY);
    if(historyData != null){
      var historyDataList = json.decode(historyData);
      if (historyDataList is List && historyDataList.length > 0) {
        for(String item in historyDataList){
          mHostory.add(item);
        }
        setState(() {

        });
      }
    }

  }


  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    //隐藏键盘
//    FocusScope.of(context).reparentIfNeeded(new FocusNode());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Color(AJColors.white),
        appBar: AppBar(
          elevation: 0.0,
          leading: SizedBox(width: 10.0,),
          brightness: Brightness.light,
          backgroundColor: Color(AJColors.white),
          actions: <Widget>[
            GestureDetector(
              onTap: () {
                Navigator.pop(context, _searchText);
              },
              child: Center(child: Container(
                  width: 30.0,
                  height: 30.0,
                  child: Text('取消', style: TextStyle(color: Colors.black),)),),
            ),
            SizedBox(width: 20.0,)
          ],
          title: Center(child: Container(
              decoration: new BoxDecoration(
                color: Color.fromRGBO(244, 244, 244, 1.0),
                borderRadius: new BorderRadius.all(new Radius.circular(30.0)),
              ),
              child: TextField(
                  controller: _searchController,
                  onChanged: (value){
                    _searchText = value;
                    if(_searchText.length == 0 || _searchText == null){
                      dataList = List();
                      setState(() {
                      });
                      return;
                    }
                  },
                  onEditingComplete: ()async{
                    bool isHostoryName = false;
                    var historyData = await LocalStorage.get(AJConfig.SEARCH_HOSTORY);
                    if (historyData != null){
                      var historyDataList = json.decode(historyData);
                      if (historyDataList is List && historyDataList.length > 0) {
                        for(String item in historyDataList){
                          if(item == _searchText){
                            isHostoryName = true;
                          }
                        }
                      }
                      if(!isHostoryName) {
                        if(_searchText != null && _searchText.trim().length > 0){
                          mHostory.add(_searchText);
                          LocalStorage.save(AJConfig.SEARCH_HOSTORY, json.encode(mHostory));
                        }
                      }
                    } else {
                      if(_searchText != null && _searchText.trim().length > 0){
                        mHostory.add(_searchText);
                        LocalStorage.save(AJConfig.SEARCH_HOSTORY, json.encode(mHostory));
                      }
                    }


                    _searchProjectName();
                    //隐藏键盘
                    FocusScope.of(context).requestFocus(new FocusNode());
                    setState(() {
                    });
                  },
                  autofocus: true,
                  decoration: InputDecoration(
//                                  contentPadding: EdgeInsets.all(15.0),
                    border: InputBorder.none,
                    prefixIcon: Icon(Icons.search),
                    hintText: "请输入要搜索的内容",
                    suffixIcon: IconButton(icon: Icon(Icons.cancel, size: 20.0,), onPressed: (){
                      setState(() {
                        _searchText = "";
                        _searchController.value = new TextEditingValue(text: _searchText ?? "");
                        dataList = List();
                        setState(() {
                        });
                      });
                    }),
//                                  icon: Icon(
//                                    Icons.search,
//                                    color: Colors.red,
//                                  ),
//                                  border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(30.0))),
//                                  prefixIcon: Icon(Icons.search)
                  )
              )),),
        ),
        body: SafeArea(
          child: Container(
            color: Color(AJColors.white),
            margin: EdgeInsets.only(top: 10.0),
            width: double.infinity,
            child: Column(
              children: <Widget>[
                SizedBox(height: 10.0,),
                _buildListWidget()
              ],
            ),
          ),
        ));
  }


  Widget _buildListWidget(){
    if(dataList.length > 0){
      return Expanded(
        child: new ListView.builder(        //可滚动显示的消息列表
          padding: new EdgeInsets.all(8.0),
//                  reverse: true,                  //反转排序，列表信息从下至上排列
          itemBuilder: (_, int index){

            return SearchItemWidget(
              imageUrl: this.dataList[index].projectIcon,
              index: index,
              itemOnChange: (i){
                NavigatorUtils.gotoReportListPage(context, "${this.dataList[index].projectId}", this.dataList[index].projectName);
                },
              projectName: this.dataList[index].projectName,
              projectEnv: this.dataList[index].projectDesc,
            );
            },    //插入聊天信息控件
          itemCount: dataList.length,
        ),
      );
    } else {
      if(_searchText.trim().length == 0 || _searchText.length == null){
        return Expanded(child: ListView(children: <Widget>[
          Container(
            margin: EdgeInsets.only(left: 12.0, top: 5.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                new Text("历史记录", style: AJConstant.subTextStyle,),
                new Padding(padding: new EdgeInsets.only(right: 8.0),
                  child: GestureDetector(
                    onTap: ()async{
                      mHostory = [];
                      LocalStorage.save(AJConfig.SEARCH_HOSTORY, json.encode(mHostory));
                      setState(() {
                      });
                    },
                    child: Icon(Icons.delete, size: 24.0, color: Color(AJColors.primaryLightValue),),),)
              ],
            ),),
          Container(
            margin: new EdgeInsets.only(left: 6.0),
            child: Wrap(
              children: List.generate(mHostory.length, (i){
                return GestureDetector(
                  onTap: () async {
                    print(mHostory[i]);
                    _searchText = mHostory[i];
                    _searchController.value = new TextEditingValue(text: _searchText ?? "");
                    _searchProjectName();
                    },
                  child: Container(
                    margin: new EdgeInsets.all(5.0),
                    padding: EdgeInsets.all(6.0),
                    decoration: BoxDecoration(
                        color: Color(AJColors.searchHistoryValue),
                        borderRadius: BorderRadius.all(Radius.circular(5.0))
                    ),
                    child: Text(
                      mHostory[i],
                      style: AJConstant.titleTextSubMain,
                    ),
                  ),
                );
              }),
            ),
          )
        ]));
      }

      return Expanded(child: EmptyWidget(emptyTitle: "暂无数据"));
    }
  }


  _searchProjectName(){
    var searchStr = null;
    if(_searchText != null && _searchText != ""){
      searchStr = _searchText;
    }
    UserDao.getSelectByPage(1, 30, searchStr).then((res){
      if (res != null && res.result){
        HomeListRepModel rep = res.data;
        if (rep.list.length > 0){
          dataList = List();
          dataList.addAll(rep.list);
        } else {
          dataList = List();

        }
      }
      setState(() {});
    });
  }

}




