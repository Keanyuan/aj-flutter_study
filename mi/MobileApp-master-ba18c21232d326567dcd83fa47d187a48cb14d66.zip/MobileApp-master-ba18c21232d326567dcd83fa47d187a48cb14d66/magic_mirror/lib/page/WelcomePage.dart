import 'dart:convert';
import 'dart:io';

import 'package:aj_flutter_plugin/aj_flutter_plugin.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:magic_mirror/dao/UserDao.dart';
import 'package:magic_mirror/style/AJColors.dart';
import 'package:magic_mirror/tools/AJState.dart';
import 'package:magic_mirror/tools/CommonUtils.dart';
import 'package:magic_mirror/tools/Config.dart';
import 'package:magic_mirror/tools/LocalStorage.dart';
import 'package:magic_mirror/tools/NavigatorUtils.dart';
import 'package:redux/redux.dart';

class WelcomePage extends StatefulWidget {
  static final String sName = '/';

  @override
  _WelcomePageState createState() => _WelcomePageState();
}

class _WelcomePageState extends State<WelcomePage> {
//定义方法渠道名
  static const platform = const MethodChannel('flutter_get_html');

  bool hadInit = false;

  @override
  void initState() {
    super.initState();
  }

  ///概念依赖关系
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();


    if(hadInit){
      return;
    }
    hadInit = true;

    _getPlatformVersion();
    ///防止多次进入
    Store<AJState> store = StoreProvider.of(context);
    CommonUtils.initStatusBarHeight(context);
    new Future.delayed(const Duration(milliseconds: 500), (){
      UserDao.initUserInfo(store).then((res){
        if(res != null && res.result){
//          NavigatorUtils.goLogin(context);

          NavigatorUtils.goHome(context);
        } else {
          NavigatorUtils.goLogin(context);

        }
        return true;
      });
    });
  }


  //调用对应方法
  _getPlatformVersion() async {
    String localHtmlData;
    AjFlutterPlugin info;

    try{
      //invoke Method 获取定义调用方法名
      if(Platform.isIOS){
        final localHtml = await platform.invokeMethod('getLocalHtml');
        localHtmlData = '$localHtml';
      }
      info = await AjFlutterPlugin.platformVersion();
    } on PlatformException catch(e){
      if(AJConfig.DEBUG){
        print("错误 $e");
      }
    }
    if(AJConfig.DEBUG){
      print("appversion: ${info.version}");
    }
    LocalStorage.save(AJConfig.APP_VERSION, info.version);
    LocalStorage.save(AJConfig.APP_ISFIRST_CHECKED, json.encode(true));
    LocalStorage.save(AJConfig.APP_LOCALHTML, localHtmlData);


  }

  @override
  Widget build(BuildContext context) {
    final widthSrcreen = MediaQuery.of(context).size.width;
    final heightScreen = MediaQuery.of(context).size.height;
    return StoreBuilder<AJState>(builder: (context, store){
      return new Container(
        width: widthSrcreen,
        height: heightScreen,
        color: Color(AJColors.white),
        child: new Center(
          child: new Image(image: new AssetImage(AJICons.AJ_WELCOME_BG), width: widthSrcreen, height: heightScreen,),
        ),
      );
    });

  }





}