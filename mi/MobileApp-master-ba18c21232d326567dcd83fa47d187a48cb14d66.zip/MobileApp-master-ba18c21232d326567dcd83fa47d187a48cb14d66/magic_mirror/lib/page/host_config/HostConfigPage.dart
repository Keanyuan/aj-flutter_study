import 'package:flutter/material.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:magic_mirror/dao/UserDao.dart';
import 'package:magic_mirror/m_widget/AJFlexButton.dart';
import 'package:magic_mirror/m_widget/AJInputWidget.dart';
import 'package:magic_mirror/request/Address.dart';
import 'package:magic_mirror/style/AJColors.dart';
import 'package:magic_mirror/tools/AJState.dart';
import 'package:magic_mirror/tools/Code.dart';
import 'package:magic_mirror/tools/CommonUtils.dart';
import 'package:magic_mirror/tools/Config.dart';
import 'package:magic_mirror/tools/LocalStorage.dart';
import 'package:magic_mirror/tools/ResultData.dart';
import 'package:redux/redux.dart';

class HostConfigPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return new _RegistPagerState();
  }
}
//用于使用到了一点点的动画效果，因此加入了SingleTickerProviderStateMixin
class _RegistPagerState extends State<HostConfigPage> with SingleTickerProviderStateMixin{

  final TextEditingController _baseHostController = new TextEditingController();
  final TextEditingController _hostController = new TextEditingController();

  var _baseHost = "";
  var _host = "";

  @override
  void initState() {
    super.initState();
    _baseHostController.value = new TextEditingValue(text: _baseHost ?? "");
    _hostController.value = new TextEditingValue(text: _host ?? "");

  }
  @override
  void dispose() {
    _baseHostController.dispose();
    _hostController.dispose();

    super.dispose();
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(AJColors.lineValue),
      appBar: new AppBar(
        title: Text("服务配置"),
        actions: <Widget>[],
      ),
      body: ListView(children: <Widget>[
        Card(
          child: ListTile(
            title: Text("当前网页地址: ${Address.baseHost}"),
            subtitle: Text("当前服务器地址: ${Address.host}"),
          ),
        ),
        Card(
          child: ListTile(
            title: Text("生产网页地址: http://mirror.anji-plus.com"),
            subtitle: Text("生产服务器地址: http://mirror.anji-plus.com"),
            onTap: (){
              CommonUtils.dialogHostConfigApp(context, "确定要使用此地址？", (){
                Address.baseHost = "http://mirror.anji-plus.com";
                Address.host = "http://mirror.anji-plus.com";
              });
            },
          ),
        ),

        Card(
          child: ListTile(
            title: Text("测试网页地址: http://10.108.11.46"),
            subtitle: Text("测试服务器地址: http://10.108.11.46:8080"),
            onTap: (){
              CommonUtils.dialogHostConfigApp(context, "确定要使用此地址？", (){
                Address.baseHost = "http://10.108.11.46";
                Address.host = "http://10.108.11.46:8080";
              });
            },
          ),
        ),

        new Padding(padding: new EdgeInsets.all(10.0)),


        Card(child: Column(children: <Widget>[
          new AJInputWidget(
            hintText: "输入新的网页地址",
            onChanged: (value){
              _baseHost = value;
            },
            controller: _baseHostController,
            fontSize: AJFont.TEXT_FIELD_FONT,
          ),

          new AJInputWidget(
            hintText: "输入新的服务器地址",
            onChanged: (value){
              _host = value;
            },
            controller: _hostController,
            fontSize: AJFont.TEXT_FIELD_FONT,
          ),
          new Padding(padding: new EdgeInsets.all(10.0)),

          new AJFlexButton(
            text: "使用",
            color: AJColors.BLUE_COLOE,
            textColor: Color(AJColors.textWhite),
            radius: 20.0,
            onPress: ()async{
              if(_baseHost.length > 0 && _host.length > 0){
                CommonUtils.dialogHostConfigApp(context, "确定要使用此地址？", (){
                  Address.baseHost = _baseHost;
                  Address.host = _host;
                });
              } else if(_baseHost.length > 0 && _host.length == 0){
                CommonUtils.dialogHostConfigApp(context, "确定要使用此地址？", (){
                  Address.baseHost = _baseHost;
                });
              } else if(_host.length > 0 &&_baseHost.length == 0){
                CommonUtils.dialogHostConfigApp(context, "确定要使用此地址？", (){
                  Address.host = _host;
                });
              } else {
                Fluttertoast.showToast(msg: "如果需要新地址请输入对应地址");
              }
            },
          ),
          new Padding(padding: new EdgeInsets.all(10.0)),

        ],),),



      ],),
    );
  }
}