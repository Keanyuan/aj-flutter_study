import 'package:flutter/material.dart';
import 'package:magic_mirror/m_widget/aj_indictor.dart';
import 'package:magic_mirror/model/GroupListModel.dart';
import 'package:magic_mirror/page/report_page/ReportListPage.dart';
import 'package:magic_mirror/style/AJColors.dart';

class ReportHomePage extends StatefulWidget{

  final String title;
  final String projectId;

  final List<GroupListModel> groupList;


  ReportHomePage(this.groupList, this.projectId,{this.title,});
  @override
  State<StatefulWidget> createState() {
    return _ReportHomePageState();
  }

}

class _ReportHomePageState extends State<ReportHomePage> with SingleTickerProviderStateMixin {

  List<Tab> tabs = [];
  List<int> ids = [];
  List items = [];

  TabController _tabController;

  @override
  void initState() {
    super.initState();
    widget.groupList.insert(0,GroupListModel(0, "全部"));
    //动画效果的异步处理
    ////需要控制的Tab页数量
    tabs = widget.groupList.map((groupModel){
      return Tab(
        text: groupModel.groupName,
      );
    }).toList();
    _tabController = new TabController(length: tabs.length, vsync: this);
    setState(() {});
    _tabController.animateTo(0);
  }

  //当整个页面dispose时，记得把控制器也dispose掉，释放内存
  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new Scaffold(
      appBar: AppBar(title: Text(widget.title ?? "监控报表"),),
      body: Container(
        width: double.infinity,
        child: Column(
          children: <Widget>[
            _buildTopBar(context),
            _bottomWidget(context),

          ],
        ),
      ),
    );
  }

  Widget _bottomWidget(BuildContext context){
    return Expanded(child: TabBarView(
      children: _buildTabPage(),
      controller: _tabController,
    ));
  }

  List<Widget> _buildTabPage(){
    List<Widget> listWidget = [];
    widget.groupList.forEach((groupModel){
      //list this.groupId,this.projectId,{this.title}
      listWidget.add(ReportListPage("${groupModel.groupId}", widget.projectId));
    });
    return listWidget;
  }

  //顶部bar
  Widget _buildTopBar(BuildContext context){

    return Container(
      width: double.infinity,
      decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Theme.of(context).dividerColor))),
      padding: new EdgeInsets.symmetric(horizontal: 8.0),
//      height: 100.0,
      child: TabBar(
        tabs: tabs,
        isScrollable: true,
        labelColor: Color(AJColors.primaryValue),
        unselectedLabelColor: Color(AJColors.normalLabelValue),
        indicatorColor: Color(AJColors.primaryValue),
//        indicator: AJIndictor(color: Color(AJColors.selectLabelValue)),
        controller: _tabController,
      ),
    );
  }

}