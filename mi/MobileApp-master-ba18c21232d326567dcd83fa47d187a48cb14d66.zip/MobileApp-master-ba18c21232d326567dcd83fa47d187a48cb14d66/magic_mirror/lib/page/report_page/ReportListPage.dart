import 'package:connectivity/connectivity.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:magic_mirror/dao/UserDao.dart';
import 'package:magic_mirror/m_widget/AJListItem.dart';
import 'package:magic_mirror/m_widget/AJListState.dart';
import 'package:magic_mirror/m_widget/EmptyWidget.dart';
import 'package:magic_mirror/model/ReportListModel.dart';
import 'package:magic_mirror/model/ReportListModelRep.dart';
import 'package:magic_mirror/request/Address.dart';
import 'package:magic_mirror/request/HttpManager.dart';
import 'package:magic_mirror/style/AJColors.dart';
import 'package:magic_mirror/tools/Config.dart';
import 'package:magic_mirror/tools/NavigatorUtils.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

class ReportListPage extends StatefulWidget{


  final String groupId;

  final String projectId;
  final String title;


  ReportListPage(this.groupId,this.projectId,{this.title});
  @override
  State<StatefulWidget> createState() {
    return _ReportListPageState();
  }
}


class _ReportListPageState extends AJListState<ReportListPage> {
//  List<HomeModel> dataList;
  List<ChartImageModel> itemList = List();
  bool isPullDown = false;
  RefreshController _refreshController;
  int indexPage = 1;
  int totalCount = 0;
  List<ReportListModel> dataList;

  @override
  void initState() {
    super.initState();
    _refreshController = new RefreshController();
    itemList = List();
    itemList.addAll([
      ChartImageModel(image: AJICons.LIST_ICON_A, title: "line", desc: "曲线图"),
      ChartImageModel(image: AJICons.LIST_ICON_B, title: "lineStack", desc: "曲线堆叠图"),
      ChartImageModel(image: AJICons.LIST_ICON_C, title: "lineZone", desc: "曲线区域图"),
      ChartImageModel(image: AJICons.LIST_ICON_D, title: "pie", desc: "饼图"),
      ChartImageModel(image: AJICons.LIST_ICON_E, title: "xBar", desc: "柱状图"),
      ChartImageModel(image: AJICons.LIST_ICON_F, title: "xBarStack", desc: "柱状堆叠图"),
      ChartImageModel(image: AJICons.LIST_ICON_G, title: "yBar", desc: "条形图"),
      ChartImageModel(image: AJICons.LIST_ICON_H, title: "yBarStack", desc: "条形堆叠图"),
      ChartImageModel(image: AJICons.LIST_ICON_I, title: "mapChina", desc: "中国地图"),
      ChartImageModel(image: AJICons.LIST_ICON_J, title: "mapWorld", desc: "世界地图"),
      ChartImageModel(image: AJICons.LIST_ICON_K, title: "map3DAnimaCount", desc: "动态计数地球"),
      ChartImageModel(image: AJICons.LIST_ICON_L, title: "map3DAnimaLine", desc: "动态迁徙地球"),
      ChartImageModel(image: AJICons.LIST_ICON_M, title: "lineMark", desc: "曲线标记图"),
      ChartImageModel(image: AJICons.LIST_ICON_N, title: "polyLine", desc: "折线图"),
      ChartImageModel(image: AJICons.LIST_ICON_O, title: "xBarLine", desc: "折线+柱状图"),
      ChartImageModel(image: AJICons.LIST_ICON_P, title: "xBarStackLine", desc: "折线+柱状堆叠图"),
    ]);

    _onRefresh(true, isFrst: true);
    setState(() {
    });
  }


  Widget _buildItem(BuildContext context, ReportListModel model , int index){
    var imageIcon = itemList[0].image;

    itemList.map((item){
      if(item.title != null && model.chartType != null){
        if(item.title == model.chartType){
          imageIcon = item.image;
        }
      }
    }).toList();

    return new AJListItem(
      padding: new EdgeInsets.symmetric(vertical: 10),
      leading: new Image.asset(imageIcon, height: 30.0,),
      title: new Text("${model.chartName ?? ""}", style: AJConstant.normalText),
      trailing: new Image.asset(AJICons.LIST_ICON_ARROW, width: 9.1, height: 16.2,),
      onTap: ()async{
        var mirrorToken = await HttpManager.getAuthorization();
        ///没有网络
        var connectivityResult = await (new Connectivity().checkConnectivity());
        var connectName = 0;
        if(connectivityResult == ConnectivityResult.mobile){
          connectName = 1;
        }
//         Address.baseHost = "http://10.108.6.131:8080";   //生产环境

//        NavigatorUtils.gotoWebPageBaseController(context, model.chartName, "http://0.0.0.0:8083");
//        NavigatorUtils.gotoWebPageBaseController(context, model.chartName, "http://10.108.12.63:8080/appChart?token=${mirrorToken}&chartType=${model.chartType}&chartId=${model.chartId}",chartId: "${model.chartId}");

//        NavigatorUtils.gotoWebPageBaseController(context, model.chartName ?? "", "https://vux.li/demos/v2/#/demo", chartId: "${model.chartId}");

        NavigatorUtils.gotoWebPageBaseController(context, model.chartName ?? "", "${Address.baseHost}/appChart?token=${mirrorToken}&chartType=${model.chartType}&chartId=${model.chartId}&connectName=${connectName}", chartId: "${model.chartId}");

//        NavigatorUtils.gotoWebPageBaseController(context, model.chartName, "http://10.108.12.67:8081/appChart?token=${mirrorToken}&chartType=${model.chartType}&chartId=${model.chartId}");

      },
    );
  }

  @override
  Widget build(BuildContext context) {

    Widget _widget = Container();
    if(dataList == null){
      _widget = Center(child: SpinKitRipple(color: Color(AJColors.primaryValue), size: 150.0,));
    } else {
      if(dataList.length == 0){
        _widget = Center(child: EmptyWidget(
          emptyTitle: "暂无数据,请点击重试",
          onPress: ()async{
            dataList = null;
            _onRefresh(true, isFrst: true);
            setState(() {

            });
          },
        ),);
      } else {
        _widget = SmartRefresher(
            controller: _refreshController,
            enablePullDown: true,
            enablePullUp: isPullDown,
            onRefresh: _onRefresh,
            footerBuilder: footerCreate,
            headerBuilder: headerCreate,
            child: new ListView.builder(
              padding: const EdgeInsets.all(16.0),
              itemBuilder: (context, i){
//                if (i.isOdd) return new Divider();
//                final index = i ~/ 2;
                return _buildItem(context, dataList[i], i);
              },
              itemCount: dataList.length,
            )
        );
      }
    }

    if(widget.groupId == "" || widget.groupId == null){
      return new Scaffold(
        appBar: AppBar(title: Text(widget.title ?? "监控报表"),),
        body: _widget,
      );
    }
    return new Scaffold(
      body: _widget,
    );
  }

  @override
  bool get wantKeepAlive => true;
  void _onRefresh(bool up, {bool isFrst = false}) {
    if(up){
      indexPage = 1;
      UserDao.queryChartListByPage(indexPage, AJConfig.PAGE_SIZE, widget.projectId, groupId: widget.groupId).then((res ){
        if(res != null && res.result){
          ReportListModelRep reportListModelRep = res.data;
          if(reportListModelRep.list.length > 0){
            dataList = List();
            totalCount = reportListModelRep.totalCount;
            indexPage ++;
            dataList.addAll(reportListModelRep.list);
          } else {
            dataList = List();
          }

          if(dataList.length >= totalCount){
            isPullDown = false;
          } else {
            isPullDown = true;
          }
          if(!isFrst){
            _refreshController.sendBack(true, RefreshStatus.idle);
            if(dataList.length >= totalCount){
              _refreshController.sendBack(false, RefreshStatus.noMore);
            } else {
              _refreshController.sendBack(false, RefreshStatus.idle);
            }
          }
        } else {
          if(!isFrst){
            _refreshController.sendBack(true, RefreshStatus.failed);
          } else {
            dataList = List();
          }
        }
        setState(() {});
      });
    } else {
      UserDao.queryChartListByPage(indexPage, AJConfig.PAGE_SIZE, widget.projectId).then((res){
        if(res != null && res.result){
          ReportListModelRep reportListModelRep = res.data;
          if(reportListModelRep.list.length > 0){
            totalCount = reportListModelRep.totalCount;
            indexPage ++;
            dataList.addAll(reportListModelRep.list);
          }
          if(dataList.length >= totalCount){
            isPullDown = false;
            _refreshController.sendBack(false, RefreshStatus.noMore);
          } else {
            isPullDown = true;
            _refreshController.sendBack(false, RefreshStatus.idle);
          }
        } else {
          _refreshController.sendBack(false, RefreshStatus.failed);
        }
        setState(() {});
      });

    }
  }
}




class ChartImageModel {
  final String image;
  final String title;
  final String desc;
  ChartImageModel({this.image, this.title, this.desc});

}