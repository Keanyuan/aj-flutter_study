import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:magic_mirror/dao/UserDao.dart';
import 'package:magic_mirror/m_widget/loading_widget.dart';
import 'package:magic_mirror/tools/AJState.dart';
import 'package:magic_mirror/tools/Config.dart';
import 'package:magic_mirror/tools/LocalStorage.dart';
import 'package:magic_mirror/tools/NavigatorUtils.dart';
import 'package:redux/redux.dart';
import 'package:aj_flutter_webview/aj_flutter_webview.dart';


//TODO 公共的WebView页面，需要标题和URL参数
class WebPageBaseController extends StatefulWidget {

  final String title;
  final String url;
  final String chartId;


  WebPageBaseController({Key key, this.title, this.url, this.chartId}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return _WebPageBaseState();
  }
}


class _WebPageBaseState extends State<WebPageBaseController> {

//  加载动画
  bool isRelaodRequest = true;

  bool loading = true;
  bool isHidden = true;
  String unit;

  //定义webview插件
//  final flutterWebViewPlugin = new AJFlutterWebviewPlugin();
  final Completer<WebViewController> _controller = Completer<WebViewController>();


  @override
  void initState() {
    ///打开横竖屏切换
    SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight, DeviceOrientation.portraitUp,]);

    super.initState();
    UserDao.queryMirrorChartByChartId(widget.chartId).then((res){
      if(res != null && res.result){
        if(res.data != null){
          setState(() {
            this.unit = "(${res.data})";
          });
        }
      }
    });

    _controller.future.then((controller){
      /// 监听WebView的加载事件
      controller.onStateChanged.listen((state){
        if(AJConfig.DEBUG){print(state.type);}

        if(state.type == WebViewState.finishLoad){
          setState(() {
            loading = false;
          });
        }
      });


      /// 监听WebView的url加载事件
      controller.onUrlChanged.listen((url){
        if(url.contains('#(pageLimitation)')){
          //口令校验失败
          Store<AJState> store = StoreProvider.of(context);
          UserDao.clearAll(store);
          Navigator.pop(context);
          NavigatorUtils.goLogin(context, result: true);
        } else if(url.contains('#(popToPreviousPage)')){
          //本地页面返回
          Navigator.pop(context);
        }
      });


      controller.onHttpError.listen((v) async{
        if(AJConfig.DEBUG){
          print("http err: ${v.code}");
          print("http err: ${v.url}");
        }

        if(isRelaodRequest && v.code.toString() != "200" && v.code.toString() != "201" ){
          isRelaodRequest = false;
          if(Platform.isIOS){
            String app_localhtml = await LocalStorage.get(AJConfig.APP_LOCALHTML);
            if(app_localhtml.length > 0){
              controller.loadLoacalUrl(app_localhtml);
            }
          } else {
            controller.loadUrl("file:///android_asset/html/NotFindPage.html");
          }

        }
      });

    });
  }






  @override
  void dispose() {
    ///打开横竖屏切换
    _controller.future.then((controller){controller.dispose();});
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp,]);
    super.dispose();

  }

  @override
  Widget build(BuildContext context) {
    final widthSrcreen = MediaQuery.of(context).size.width;
    final heightScreen = MediaQuery.of(context).size.height;
    List<Widget> titleContent = [];
    titleContent.add(Expanded(child: Center(child: new Text(
      "${widget.title}",
      style: new TextStyle(color: Colors.white),
    ))));
    titleContent.add(Text("${this.unit ?? ""}", style: new TextStyle(color: Colors.white)));
    if(loading){
      titleContent.add(new CupertinoActivityIndicator());
    }

    titleContent.add(new Container(width: 50.0,));
    if(AJConfig.DEBUG){
      print(widget.url);
    }

    return Scaffold(appBar: new AppBar(
        leading: new GestureDetector(
          child: new Icon(Icons.arrow_back_ios),
          onTap: (){
            Navigator.pop(context);
          },
        ),
        actions: <Widget>[
          new GestureDetector(
            child: Container(width: 40.0, height: 40.0, child: new Icon(Icons.more_horiz)),
            onTap: (){
  //                flutterWebViewPlugin.launch(widget.url, rect: new Rect.fromLTWH(0.0, 0.0, widthSrcreen, heightScreen));
              if(this.isHidden){
                _controller.future.then((flutterWebViewPlugin){
                  flutterWebViewPlugin.evaluateJavascript("topDivHidden(0)");
                });
              } else {
                _controller.future.then((flutterWebViewPlugin){
                  flutterWebViewPlugin.evaluateJavascript("topDivHidden(1)");
                });
              }

              setState(() {
                this.isHidden = !this.isHidden;
              });
            },
          ),
          SizedBox(width: 10.0,)
        ],
        title: new Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: titleContent,
        ),
        iconTheme: new IconThemeData(color: Colors.white),
      ),
      body: AJStackLoading(
          child: AJWebview(
            initialUrl: widget.url,
            javascriptMode: JavascriptMode.unrestricted,
            withLocalUrl: false,
            onWebViewCreated: (WebViewController webViewController) {
              _controller.complete(webViewController);
            },
          ),
          isLoading: loading),
    );
  }

}
