
class Address {
  //develop 二期
  //10.108.12.11
  static String baseHost = "http://mirror.anji-plus.com";   //生产环境
//  static String baseHost = "http://10.108.6.131"; //开发环境
//  static String baseHost = "http://10.108.11.46"; //测试环境


  static String host = "http://mirror.anji-plus.com";//生产环境
//  static const String host = "http://10.108.6.131:8080";//开发环境
//  static const String host = "http://10.108.11.46:8080";//测试环境

  //二期
  static const String accessUserLoginUrl = "/business/accessUser/login";//登录
  static const String createOrUpdateUser = "/business/accessUser/createOrUpdateUser";//注册
  static const String accessUserSendMail = "/business/accessUser/sendMail";//发送email

  static const String getVerificationCode = "/business/accessUser/getVerificationCode";//获取code码
  static const String selectByPage = "/business/project/selectByPage";//首页
  static const String queryChartListByPage = "/business/chart/queryChartListByPage"; //项目图表列表
  static const String baseParameter_selectOne = "/business/baseParameter/selectOne"; //项目图表列表
  static const String queryGroupList = "/business/accessUser/queryGroupList"; //获取分组列表
  static const String getMirrorChartByChartId = "/chart/mirrorChart/getMirrorChartByChartId"; //获取分组列表


}