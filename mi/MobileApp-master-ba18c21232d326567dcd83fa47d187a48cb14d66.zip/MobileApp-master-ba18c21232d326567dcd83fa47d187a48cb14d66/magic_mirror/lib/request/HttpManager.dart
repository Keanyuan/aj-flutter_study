import 'package:dio/dio.dart';
import 'package:connectivity/connectivity.dart';
import 'package:magic_mirror/request/Address.dart';
import 'package:magic_mirror/request/SignConfig.dart';
import 'dart:collection';
import 'package:magic_mirror/tools/Code.dart';
import 'package:magic_mirror/tools/Config.dart';
import 'package:magic_mirror/tools/LocalStorage.dart';
import 'package:magic_mirror/tools/ResultData.dart';

///http请求
class HttpManager {
  static const CONTENT_TYPE_JSON = "application/json";
  static const CONTENT_TYPE_FORM = "application/x-www-form-urlencoded";
  static Map<String, String> optionParams = {
    "mirrorToken": null,
    "content-Type": CONTENT_TYPE_JSON
  };
  ///发起网络请求
  ///[ url] 请求url
  ///[ param] 请求参数
  ///[ header] 外加头
  ///[ isNeedToken] 是否需要token
  ///[ optionMetod] 请求类型 post、get
  ///[ noTip] 是否需要返回错误信息 默认不需要
  ///[ needSign] 是否需要Sign校验  默认需要
  ///[ needError] 是否需要错误提示
  static requestData(url, param, Map<String, String> header, {bool isNeedToken = true, String optionMetod="post", noTip = false, needSign = true, needError = true}) async {
    ///没有网络
    var connectivityResult = await (new Connectivity().checkConnectivity());
    if (connectivityResult == ConnectivityResult.none) {
      return new ResultData(Code.errorHandleFunction(Code.NETWORK_ERROR, "", noTip), false, Code.NETWORK_ERROR);
    }

    ///头部
    Map<String, String> headers = new HashMap();
    if (header != null) {
      headers.addAll(header);
    }

    //请求协议 post 、get
    Options option = new Options(method: optionMetod);

    ///设置头部
    if (option != null) {
      option.headers = headers;
    }

    option.connectTimeout = 15000;

    //获取token
    var mirrorToken = await getAuthorization();

    if(isNeedToken){
      if(mirrorToken == "") {
        if(needError) {
          return new ResultData(Code.errorHandleFunction(Code.NETWORK_FALID, "未登录或登录已过期", noTip), false, Code.NETWORK_FALID);
        }
      }
    }

    var params = param;
    if(needSign){
      //获取加密的请求参数
      params = await SignConfig.signData(param, mirrorToken);
    }
//    return null;
    ///初始化请求类
    Dio dio = new Dio();
    Response response;

    try {
      ///开始请求
      response = await dio.request(Address.host + url, data: params, options: option);
    }on DioError catch (e) {
      Response errorResponse;
      if (e.response != null) {
        errorResponse = e.response;
      } else {
        errorResponse = new Response(statusCode: 666);
      }

      //超时
      if (e.type == DioErrorType.CONNECT_TIMEOUT) {
        errorResponse.statusCode = Code.NETWORK_TIMEOUT;
      }

      if (AJConfig.DEBUG) {
        print('请求异常: ' + e.toString());
        print('请求异常url: ' + url);
      }
      ///请求失败处理
      if(needError) {
        return new ResultData(Code.errorHandleFunction(errorResponse.statusCode, e.message, noTip), false, errorResponse.statusCode);
      }
    }


    if (AJConfig.DEBUG) {
      print('请求url: ' + Address.host + url);
      print('请求头: ' + option.headers.toString());
      if (params != null) {
        print('请求参数: ' + params.toString());
      }
      if (response != null) {
        print('返回参数: ' + response.toString());
      }

    }

    try {
      if (option.contentType != null && option.contentType.primaryType == "text") {
        return new ResultData(response.data, true, Code.SUCCESS);
      } else {
        var responseJson = response.data;
        ///保存token
        if(url.contains(Address.accessUserLoginUrl)){
          if (response.statusCode == 200 && responseJson["repCode"] == "0000") {
            await LocalStorage.save(AJConfig.TOKEN_KEY, responseJson["repData"]["token"]);
          }
        }

        if(response.statusCode == 200){
          ///请求链接成功
          if(responseJson["repCode"] == "0000"){
            return new ResultData(responseJson["repData"], true, Code.SUCCESS, headers: response.headers);
          } else if(responseJson["repCode"] == "0104" && !url.contains(Address.accessUserLoginUrl)){
            if(needError){
              return new ResultData(Code.errorHandleFunction(Code.REQUEST_SHIBBOLETH, responseJson["repData"], noTip), false, Code.REQUEST_SHIBBOLETH);
            }
          }
//          else if(responseJson["repCode"] == "0104"){//
//
//          }
          else {
            if(needError){
              return new ResultData(Code.errorHandleFunction(response.statusCode, responseJson["repMsg"], noTip), false, response.statusCode);
            }
          }
        }
      }
    } catch(e){
      if(needError){
        return new ResultData(Code.errorHandleFunction(response.statusCode, "请求失败", noTip), false, response.statusCode);
      }
    }

    if(needError){
      return new ResultData(Code.errorHandleFunction(Code.NETWORK_FALID, "请求失败", noTip), false, Code.NETWORK_FALID);
    } else {
      return new ResultData(null, false, Code.NETWORK_FALID);
    }
  }

  ///清除授权
  static clearAuthorization() {
    LocalStorage.remove(AJConfig.TOKEN_KEY);
  }

  ///获取授权token
  static getAuthorization() async {
    String token = await LocalStorage.get(AJConfig.TOKEN_KEY);
    if (token == null) {
      return "";
    } else {
      return token;
    }
  }

}