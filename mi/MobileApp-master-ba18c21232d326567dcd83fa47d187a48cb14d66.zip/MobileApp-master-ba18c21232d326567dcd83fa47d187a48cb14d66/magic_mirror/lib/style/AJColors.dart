
import 'package:flutter/material.dart';

class AJColors {
  //0xFF24292E  十六进制颜色值   0xFF 表示透明度100% 24292E表示对应颜色值  0xFF19234D
  static const int primaryValue = 0xFF203160;
  static const int primaryLightBuleValue = 0xFF90D7EA;
  static const int primaryDarkValue = 0xFF121917;
  static const int primaryLightValue = 0xFFe9e9e9;
  static const int white = 0xFFFFFFFF;
  static const int lightGray = 0xFF999999;
  static const int borderLightValue = 0xFFF7F7F7;
  static const int searchHistoryValue = 0xFFE0E0E0;
  static const int selectLabelValue = 0xFFF15A22;
  static const int normalLabelValue = 0xFFC3C2C2;
  static const int lineValue = 0xFFF6F6F6;




  static const Color BLUE_COLOE = Colors.blue;
  static const Color RED_COLOE = Colors.red;
  static const Color PRIMARY_COLOR = Color(primaryValue);

  static const Color Light_BLUE_COLOE = Color(0xFF7AB1F9);

  
  static const int textWhite = 0xFFFFFFFF;

  //黑色
  static const int mainTextColor = primaryDarkValue;
  //描述字体颜色
  static const int subTextColor = 0xff959595;



  //白色透明
  static const int primaryDarkTransparentValue = 0xaaffffff;
  static const int textColorWhite = white;



  static const MaterialColor primarySwatch = const MaterialColor(
    primaryValue,
    const<int, Color>{
      50: const Color(primaryLightValue),
      100: const Color(primaryLightValue),
      200: const Color(primaryLightValue),
      300: const Color(primaryLightValue),
      400: const Color(primaryLightValue),
      500: const Color(primaryValue),
      600: const Color(primaryDarkValue),
      700: const Color(primaryDarkValue),
      800: const Color(primaryDarkValue),
      900: const Color(primaryDarkValue),
    },
  );

}


class AJICons {
  static const String FONT_FAMILY = 'wxcIconFont';
  static const String DEFAULT_USER_BG_ICON = 'assets/images/login_bg.png';
  static const String AJ_WELCOME_BG = 'assets/images/aj_welcome.png';

  static const String HOME_TOP_BG = 'assets/images/home_top.png';
  static const String HOME_ICON_SEARCH = 'assets/images/icon_search.png';
  static const String HOME_EXIT = 'assets/images/home_exit.png';
  static const String PLACEHOLDER_IMAGE = 'assets/images/placeholder_image.png';

  static const String DEFAULT_REGISTER_ICON = 'assets/images/register_icon.png';

  static const String LIST_ICON_A = 'assets/images/list_icon_a.png';

  static const String LIST_ICON_B = 'assets/images/list_icon_b.png';

  static const String LIST_ICON_C = 'assets/images/list_icon_c.png';

  static const String LIST_ICON_D = 'assets/images/list_icon_d.png';

  static const String LIST_ICON_E = 'assets/images/list_icon_e.png';

  static const String LIST_ICON_F = 'assets/images/list_icon_f.png';

  static const String LIST_ICON_G = 'assets/images/list_icon_g.png';

  static const String LIST_ICON_H = 'assets/images/list_icon_h.png';
  static const String LIST_ICON_I = 'assets/images/list_icon_i.png';
  static const String LIST_ICON_J = 'assets/images/list_icon_j.png';
  static const String LIST_ICON_K = 'assets/images/list_icon_k.png';
  static const String LIST_ICON_L = 'assets/images/list_icon_l.png';
  static const String LIST_ICON_M = 'assets/images/list_icon_m.png';
  static const String LIST_ICON_N = 'assets/images/list_icon_n.png';
  static const String LIST_ICON_O = 'assets/images/list_icon_o.png';
  static const String LIST_ICON_P = 'assets/images/list_icon_p.png';


  static const String LIST_ICON_ARROW = 'assets/images/list_arrow.png';



  static const IconData ISSUE_EDIT_LINKA = Icons.account_circle;
  //用户名
  static const IconData LOGIN_USER = const IconData(0xe666, fontFamily: AJICons.FONT_FAMILY);
  //密码
  static const IconData LOGIN_PW = const IconData(0xe60e, fontFamily: AJICons.FONT_FAMILY);

  //手机号
  static const IconData REGIST_PHONE_NUM = Icons.phone_android;
  //邮箱
  static const IconData REGIST_EMAIL = Icons.email;

  static const IconData MORE = Icons.more_horiz;

}

class AJFont {
  //输入框字体大小
  static const double TEXT_FIELD_FONT = 18.0;

}


///文本样式
class AJConstant {

  //项目名称字体
  static const titleTextSize = 16.0;


  static const normalTextSize = 18.0;
  static const subTextSize = 12.0;






  static const titleTextWhite = TextStyle(
    color: Color(AJColors.textColorWhite),
    fontSize: titleTextSize,
  );
  static const titleTextWhiteBold = TextStyle(
    color: Color(AJColors.textColorWhite),
    fontSize: titleTextSize,
    fontWeight: FontWeight.bold,
  );

  static const titleTextMain = TextStyle(
    color: Color(AJColors.mainTextColor),
    fontSize: titleTextSize,
  );

  static const titleTextSubMain = TextStyle(
    color: Color(AJColors.subTextColor),
    fontSize: subTextSize,
  );

  static const titleTextBold = TextStyle(
    color: Color(AJColors.mainTextColor),
    fontSize: titleTextSize,
    fontWeight: FontWeight.bold,
  );

  static const normalText = TextStyle(
    color: Color(AJColors.mainTextColor),
    fontSize: normalTextSize,
  );
  static const normalTextBold = TextStyle(
    color: Color(AJColors.mainTextColor),
    fontSize: normalTextSize,
    fontWeight: FontWeight.bold,
  );

  static const normalTextWhite = TextStyle(
    color: Color(AJColors.textColorWhite),
    fontSize: normalTextSize,
  );
  static const subTextStyle = TextStyle(
    color: Color(AJColors.subTextColor),
    fontSize: subTextSize,
  );
  static const subTextStyleWhite = TextStyle(
    color: Color(AJColors.white),
    fontSize: subTextSize,
  );


  static const normalTextPrimary = TextStyle(
    color: Color(AJColors.primaryValue),
    fontSize: normalTextSize,
  );



}