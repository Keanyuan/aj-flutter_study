
import 'package:event_bus/event_bus.dart';
import 'package:magic_mirror/tools/HttpErrorEvent.dart';

class Code {
  ///网络错误
  static const NETWORK_ERROR = -1;
  //口令校验失败
  static const REQUEST_SHIBBOLETH = 0104;

  ///网络超时
  static const NETWORK_TIMEOUT = -2;

  ///网络返回数据格式化一次
  static const NETWORK_JSON_EXCEPTION = -3;

  static const NETWORK_FALID = 0;

  static const SUCCESS = 200;

  static final EventBus eventBus = new EventBus();

  static errorHandleFunction(code, message, noTip){


    if(noTip){
      return message;
    }

    //eventBus 注册
    eventBus.fire(new HttpErrorEvent(code, message));
    return message;

  }
}