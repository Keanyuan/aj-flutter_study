
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:ui';

import 'package:aj_flutter_plugin/aj_flutter_plugin.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_redux/flutter_redux.dart';

import 'package:magic_mirror/dao/UserDao.dart';
import 'package:magic_mirror/model/AppVersionModel.dart';
import 'package:magic_mirror/reducer/ThemeDataReducer.dart';
import 'package:magic_mirror/style/AJColors.dart';
import 'package:magic_mirror/tools/AJState.dart';
import 'package:magic_mirror/tools/Config.dart';
import 'package:magic_mirror/tools/LocalStorage.dart';
import 'package:magic_mirror/tools/NavigatorUtils.dart';
import 'package:redux/redux.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';


///通用逻辑
class CommonUtils {
  static double sStaticBarHeight = 0.0;

  //颜色列表
  static List<Color> getThemeListColor() {
    return [
      AJColors.primarySwatch,
      Colors.brown,
      Colors.blue,
      Colors.teal,
      Colors.amber,
      Colors.blueGrey,
      Colors.deepOrange,
    ];
  }

  //初始化状态栏高度
  static void initStatusBarHeight(context) async {
    double _statusBarHeight = MediaQuery.of(context).padding.top;
    _statusBarHeight = MediaQueryData.fromWindow(window).padding.top;
    sStaticBarHeight = _statusBarHeight;
//    sStaticBarHeight = await FlutterStatusbar.height / MediaQuery.of(context).devicePixelRatio;
  }


  /*改变主题*/
  static pushTheme(Store store, int index){
    ThemeData themeData;
    List<Color> colors = getThemeListColor();
    themeData = new ThemeData(primarySwatch: colors[index], platform: TargetPlatform.iOS);
    store.dispatch(new RefreshThemeDataAction(themeData));
  }

  //加载样式
  static Future<Null> showLoadingDialog(BuildContext context) {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return new Material(
              color: Colors.transparent,
              child: WillPopScope(
                onWillPop: () => new Future.value(false),
                child: Center(
                  child: new Container(
                    width: 200.0,
                    height: 200.0,
                    padding: new EdgeInsets.all(4.0),
                    decoration: new BoxDecoration(
                      color: Colors.transparent,
                      //用一个BoxDecoration装饰器提供背景图片
                      borderRadius: BorderRadius.all(Radius.circular(4.0)),
                    ),
                    child: new Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        new Container(child: SpinKitFadingGrid(color: Color(AJColors.white))),
                        new Container(height: 10.0),
                        new Container(child: new Text("努力加载中···", style: AJConstant.normalTextWhite)),
                      ],
                    ),
                  ),
                ),
              ));
        });
  }

  /// 单击提示退出
  static Future<bool> dialogExitApp(BuildContext context){
    return showDialog(
        context: context,
        builder: (context) => new AlertDialog(
          content: new Text("确定要退出应用？"),
          actions: <Widget>[
            new FlatButton(
              onPressed: (){
                Navigator.of(context).pop(false);
              },
              child: new Text("取消"),
            ),
            new FlatButton(
                onPressed: (){
                  Navigator.of(context).pop();
                  SystemNavigator.pop();
                },
                child: new Text("确定"))
          ],
        )
    );
  }

  /// 单击提示退出
  static Future<bool> dialogHostConfigApp(BuildContext context,String title, VoidCallback confirmTap) {
    return showDialog(
        context: context,
        builder: (context) => new AlertDialog(
          content: new Text(title),
          actions: <Widget>[
            new FlatButton(
              onPressed: (){
                Navigator.of(context).pop();
              },
              child: new Text("取消"),
            ),
            new FlatButton(
                onPressed: (){
                  confirmTap();
                  Navigator.of(context).pop();
                  Navigator.of(context).pop();
                },
                child: new Text("确定"))
          ],
        )
    );
  }

  /// 提示修改密码链接发送到邮箱
  static Future<bool> dialogEmailPrompt(BuildContext context){
    return showDialog(
        context: context,
        builder: (context) => new AlertDialog(
          content: new Text("您的请求已发送成功，请查看注册邮箱收到的邮件，按照提示进行重置密码！谢谢！"),
          actions: <Widget>[
            new FlatButton(
                onPressed: (){
                  Navigator.of(context).pop();
                  Navigator.pop(context);
                },
                child: new Text("确定"))
          ],
        )
    );
  }


  /// 单击提示退出
  static Future<bool> dialogUpdateApp(BuildContext context, AppVersionModel appVersionModel){
    if(appVersionModel.isInfoShow){
      return showDialog(
          context: context,
          builder: (context) => new AlertDialog(
            content: new Text(appVersionModel.paramDesc),
            actions: <Widget>[
              new FlatButton(
                onPressed: (){
                  Navigator.of(context).pop(false);
                },
                child: new Text("取消"),
              ),
              new FlatButton(
                  onPressed: () async{
                    Navigator.of(context).pop();
                    if(Platform.isIOS){
                      await launch(appVersionModel.remark);
                    } else if(Platform.isAndroid){
                      await launch(appVersionModel.remark);
                    } else {
                      await launch(appVersionModel.remark);
                    }
                  },
                  child: new Text("确定"))
            ],
          )
      );
    } else {
      return null;
    }

  }

  static Future<bool> dialogExitLoginApp(BuildContext context){
    return showDialog(
        context: context,
        builder: (context) => new AlertDialog(
          content: new Text("确定要退出登录？"),
          actions: <Widget>[
            new FlatButton(
              onPressed: (){
                Navigator.of(context).pop(false);
              },
              child: new Text("取消"),
            ),
            new FlatButton(
                onPressed: (){
                  Navigator.of(context).pop();
                  ///防止多次进入
                  Store<AJState> store = StoreProvider.of(context);
                  UserDao.clearAll(store);
                  NavigatorUtils.goLogin(context, result: true);
                },
                child: new Text("确定"))
          ],
        )
    );
  }

  ///大陆手机号码11位数，匹配格式：前三位固定格式+后8位任意数
  /// 此方法中前三位格式有：
  /// 13+任意数 * 15+除4的任意数 * 18+除1和4的任意数 * 17+除9的任意数 * 147
  static bool isChinaPhoneLegal(String str) {
    return new RegExp('^((13[0-9])|(15[^4])|(166)|(17[0-8])|(18[0-9])|(19[8-9])|(147,145))\\d{8}\$').hasMatch(str);
  }

  static bool isChineseCharacter(String str) {
    return new RegExp('^.*[\u4e00-\u9fa5]+.*\$').hasMatch(str);
  }




//  var regEmail=/^([a-zA-Z0-9]+[_|\-|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\-|\.]?)*[a-zA-Z0-9]+(\.[a-zA-Z]{2,3})+$/;

  static bool isEmail(String str) {
    return new RegExp('^[a-zA-Z0-9_.-]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z0-9]{2,6}\$').hasMatch(str);
  }

  static String getCaptchaStr(int kCharCount){
    final changeList = ["0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"];
    var changeStr = "";
    final random = new Random();

    for (var x in changeList.sublist(0, kCharCount)) {
      var index = random.nextInt(changeList.length);
      changeStr = changeStr + changeList[index];
    }
    return changeStr;
  }



  //调用对应方法
  static checkVersion(BuildContext context) async {
    //获取数据
    var info = await LocalStorage.get(AJConfig.APP_ISFIRST_CHECKED);
    if(info != null){
      //解析数据
      var isCheck = json.decode(info);
      if(isCheck){
        String _app_version = await LocalStorage.get(AJConfig.APP_VERSION);
        if(AJConfig.DEBUG){
          print("appversion: $_app_version");
        }
        UserDao.checkVersion(_app_version).then((appVersionModel){
          AppVersionModel appVersionModelTemp = appVersionModel;
          if(appVersionModelTemp.isInfoShow){
            CommonUtils.dialogUpdateApp(context, appVersionModelTemp);
          }
          //保存数据并进行编码
          LocalStorage.save(AJConfig.APP_ISFIRST_CHECKED, json.encode(false));
        });
      }
    }

  }
}