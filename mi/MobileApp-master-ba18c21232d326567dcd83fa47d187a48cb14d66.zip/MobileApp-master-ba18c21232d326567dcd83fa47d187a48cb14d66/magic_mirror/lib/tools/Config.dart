
class AJConfig {
  static const PAGE_SIZE = 20;
  static const DEBUG = false;

/// //////////////////////////////////////常量////////////////////////////////////// ///
  static const TOKEN_KEY = "token";

  static const USER_NAME_KEY = "user-name";
  static const PW_KEY = "user-pw";

  //用户信息
  static const USER_INFO = "user-info";
  static const SEARCH_HOSTORY= "search-hostory";

  static const APP_VERSION= "app-version";
  static const APP_ISFIRST_CHECKED= "app-isfirst-checked";
  static const APP_LOCALHTML= "app-localHtml";



  //主题颜色
  static const THEME_COLOR = "theme-color";

  //图表地址名
  static final dirImage = 'assets/images/';

}