
import 'package:flutter/material.dart';
import 'package:magic_mirror/model/GroupListModel.dart';
import 'package:magic_mirror/model/ReportListModel.dart';
import 'package:magic_mirror/page/ForgetPasswordPage.dart';
import 'package:magic_mirror/page/HomePage.dart';
import 'package:magic_mirror/page/LoginPage.dart';
import 'package:magic_mirror/page/RegisterPage.dart';
import 'package:magic_mirror/page/host_config/HostConfigPage.dart';
import 'package:magic_mirror/page/report_page/ReportListPage.dart';
import 'package:magic_mirror/m_widget/BaseScaffodWidget.dart';
import 'package:magic_mirror/page/SearchPage.dart';
import 'package:magic_mirror/page/report_page/ReportHomePage.dart';
import 'package:magic_mirror/page/web_page/WebPageBaseController.dart';


class NavigatorUtils {
  //首页
  static goHome(BuildContext context){
    Navigator.pushReplacementNamed(context, HomePage.sName);
  }

  //登录
  static goLogin(BuildContext context, {result = false}){
    if (result) {
      Navigator.of(context).push(new PageRouteBuilder(
        opaque: true,
        pageBuilder:
            (BuildContext context, _, __) {
          return new LoginPage();
        },
      ));
    } else {
      Navigator.pushReplacementNamed(context, LoginPage.sName, result: result);
    }
  }

  //个人注册
  static gotoRegisterPage(BuildContext context){
    return Navigator.push(context, new MaterialPageRoute(
        builder: (context) => new RegisterPage()),
    );
  }

  //忘记密码？
  static gotoForgetPasswordPage(BuildContext context){
    Navigator.push(context, new MaterialPageRoute(
        builder: (context) => new ForgetPasswordPage()),
    );
  }

  //忘记密码？
  static gotoHostConfigPage(BuildContext context){
    Navigator.push(context, new MaterialPageRoute(
        builder: (context) => new HostConfigPage()),
    );
  }


  //列表
  static gotoReportListPage(BuildContext context, projectId, String title){
    Navigator.push(context, new MaterialPageRoute(
        builder: (context) => new ReportListPage("", "${projectId}", title: title)),
    );
  }

  //列表home
  static gotoReportHomePage(BuildContext context, List<GroupListModel> groupList, String title, projectId){

    Navigator.push(context, new MaterialPageRoute(
        builder: (context) => new ReportHomePage(groupList, "${projectId}", title: title)),
    );
  }
  static gotoWebPageBaseController(BuildContext context, title, url, {String chartId}){
    Navigator.push(context, new MaterialPageRoute(
        builder: (context) => new WebPageBaseController(title: title,chartId: chartId, url: url,)),
    );
  }






  ///搜索页
  static gotoSearchPage(BuildContext context, String searchText){
//    Navigator.push(context, AnimationPageRoute(
//        sildeTween: Tween(begin: Offset(0.0, - 1.0), end: Offset.zero),
//        builder: (c){
//          return SearchPage();
//        }
//    ));

    return Navigator.of(context).push(new PageRouteBuilder(
      opaque: true,
      pageBuilder:
          (BuildContext context, _, __) {
        return new SearchPage(editText: searchText);
      },
    ));
  }



}